package com.example.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.TopAppHeader
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.util.Locale

@Composable
fun HomeScreen(
    viewModel: T999ViewModel,
    onNavigateToSlot: () -> Unit,
    onNavigateToRecharge: () -> Unit,
    onNavigateToWallet: () -> Unit,
    onNavigateToPaymentHistory: () -> Unit,
    onNavigateToLuckySpin: () -> Unit,
    onNavigateToDailyBonus: () -> Unit,
    onNavigateToLeaderboard: () -> Unit,
    onNavigateToReferral: () -> Unit,
    onNavigateToAdmin: () -> Unit,
    onNavigateToProfile: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val configs by viewModel.configs.collectAsState()
    val announcement = configs["announcement"] ?: "Welcome to T999 Social Gaming! 100% virtual social gaming experience."

    val formattedCoins = NumberFormat.getNumberInstance(Locale.US).format(currentUser?.coinBalance ?: 0L)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        contentPadding = PaddingValues(bottom = 90.dp)
    ) {
        // App Top Bar
        item {
            TopAppHeader(
                currentUser = currentUser,
                onBuyCoinsClick = onNavigateToRecharge,
                onProfileClick = onNavigateToProfile,
                onNotificationsClick = onNavigateToWallet,
                onSoundToggle = {
                    viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled
                },
                isSoundOn = viewModel.soundManager.isSoundEnabled
            )
        }

        // Live Announcement Bar
        item {
            Surface(
                color = DarkSurfaceVariant,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .border(BorderStroke(1.dp, NeonGreenSubtle))
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "🔥", fontSize = 12.sp)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = announcement,
                        color = NeonGreenBright,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }

        // Hero Promotional Banner
        item {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .border(1.dp, NeonGreen.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
                    .shadow(12.dp, RoundedCornerShape(20.dp), ambientColor = NeonGreen)
            ) {
                Image(
                    painter = painterResource(id = R.drawable.t999_hero_banner),
                    contentDescription = "T999 Mega Banner",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                )

                // Overlay Gradient
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Transparent, DarkBackground.copy(alpha = 0.9f))
                            )
                        )
                )

                // Banner Contents
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp)
                        .padding(16.dp),
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "T999 NEON WILDS",
                            color = NeonGreenBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Win Up to 50x Mega Multipliers!",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Button(
                        onClick = onNavigateToSlot,
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = TextOnNeon
                        ),
                        modifier = Modifier.testTag("play_now_banner_button")
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("PLAY NOW", fontWeight = FontWeight.Black, fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // Quick Primary Actions (Buy Coins, Wallet, Payment History)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Buy Coins
                HomeQuickActionCard(
                    title = "Buy Coins",
                    subtitle = "From Rs.100",
                    icon = "⚡",
                    highlightColor = NeonGreen,
                    onClick = onNavigateToRecharge,
                    modifier = Modifier.weight(1f)
                )

                // Wallet
                HomeQuickActionCard(
                    title = "My Wallet",
                    subtitle = "$formattedCoins Coins",
                    icon = "💳",
                    highlightColor = GoldAccent,
                    onClick = onNavigateToWallet,
                    modifier = Modifier.weight(1f)
                )

                // Payment History
                HomeQuickActionCard(
                    title = "History",
                    subtitle = "TILL Status",
                    icon = "🧾",
                    highlightColor = CyberCyan,
                    onClick = onNavigateToPaymentHistory,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Special Rewards Hub (Daily Bonus & Lucky Spin)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Daily Bonus Banner Card
                GlowCard(
                    glowColor = GoldGlow,
                    borderColor = GoldAccent.copy(alpha = 0.5f),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToDailyBonus() }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "🎁", fontSize = 24.sp)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(GoldAccent.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("DAY ${currentUser?.dailyStreak ?: 1}", color = GoldAccent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Daily Bonus", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Claim up to +1000 Coins", color = TextSecondary, fontSize = 11.sp)
                    }
                }

                // Lucky Wheel Spin Card
                GlowCard(
                    glowColor = ElectricPurple,
                    borderColor = ElectricPurple.copy(alpha = 0.5f),
                    modifier = Modifier
                        .weight(1f)
                        .clickable { onNavigateToLuckySpin() }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(text = "🎡", fontSize = 24.sp)
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(NeonGreen.copy(alpha = 0.2f))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text("${currentUser?.luckySpinsRemaining ?: 0} SPINS", color = NeonGreenBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Lucky Wheel", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text("Win 2500x Jackpot", color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        // Section Title: Featured Games
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FEATURED SLOT GAMES",
                    color = NeonGreenBright,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 15.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = "3 Games",
                    color = TextMuted,
                    fontSize = 12.sp
                )
            }
        }

        // Featured Games Grid / List
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // Game 1: T999 Neon Wilds (Active)
                SlotGameCard(
                    title = "T999 Neon Wilds",
                    badge = "HOT • FLAGSHIP",
                    description = "50x Super Wild Jackpots & Neon Reels",
                    rtpText = "Fair Social RTP: 97.8%",
                    iconSymbol = "⚡",
                    accentColor = NeonGreen,
                    onClick = onNavigateToSlot
                )

                // Game 2: Cyber 777 Jackpot (Active)
                SlotGameCard(
                    title = "Cyber 777 Jackpot",
                    badge = "MEGA JACKPOT",
                    description = "Triple 7s with Instant High Roller Bets",
                    rtpText = "Fair Social RTP: 96.5%",
                    iconSymbol = "7️⃣",
                    accentColor = GoldAccent,
                    onClick = onNavigateToSlot
                )

                // Game 3: Emerald Dragon Slots (Active)
                SlotGameCard(
                    title = "Emerald Dragon Reels",
                    badge = "VIP EXCLUSIVE",
                    description = "Dragon Multipliers & Cyber Gems",
                    rtpText = "Fair Social RTP: 98.1%",
                    iconSymbol = "🐉",
                    accentColor = CyberCyan,
                    onClick = onNavigateToSlot
                )
            }
        }

        // Special Community Row (Leaderboard, Referral, Promo)
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                CyberOutlinedButton(
                    text = "Leaderboard",
                    onClick = onNavigateToLeaderboard,
                    icon = Icons.Default.MilitaryTech,
                    borderColor = GoldAccent,
                    textColor = GoldAccent,
                    modifier = Modifier.weight(1f)
                )

                CyberOutlinedButton(
                    text = "Refer & Earn",
                    onClick = onNavigateToReferral,
                    icon = Icons.Default.Share,
                    borderColor = NeonGreen,
                    textColor = NeonGreen,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Admin Access Bar if user is admin
        if (currentUser?.isAdmin == true) {
            item {
                Spacer(modifier = Modifier.height(12.dp))
                GlowCard(
                    glowColor = GoldAccent,
                    borderColor = GoldAccent,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                        .clickable { onNavigateToAdmin() }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = GoldAccent)
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Admin Control Master", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Text("Manage TILL Payments, Users & Packages", color = TextSecondary, fontSize = 11.sp)
                            }
                        }
                        Text("OPEN ➔", color = GoldAccent, fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
                    }
                }
            }
        }

        // Virtual currency disclaimer
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                VirtualCurrencyDisclaimerCard()
            }
        }
    }
}

@Composable
fun HomeQuickActionCard(
    title: String,
    subtitle: String,
    icon: String,
    highlightColor: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    GlowCard(
        glowColor = highlightColor,
        borderColor = highlightColor.copy(alpha = 0.4f),
        modifier = modifier.clickable { onClick() }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = icon, fontSize = 22.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = TextPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 13.sp
            )
            Text(
                text = subtitle,
                color = highlightColor,
                fontWeight = FontWeight.SemiBold,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun SlotGameCard(
    title: String,
    badge: String,
    description: String,
    rtpText: String,
    iconSymbol: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    GlowCard(
        glowColor = accentColor,
        borderColor = accentColor.copy(alpha = 0.3f),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(DarkSurfaceVariant, accentColor.copy(alpha = 0.2f))
                            )
                        )
                        .border(1.dp, accentColor, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = iconSymbol, fontSize = 26.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            color = TextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(accentColor.copy(alpha = 0.2f))
                                .padding(horizontal = 4.dp, vertical = 1.dp)
                        ) {
                            Text(
                                text = badge,
                                color = accentColor,
                                fontSize = 8.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = description,
                        color = TextSecondary,
                        fontSize = 11.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )

                    Text(
                        text = rtpText,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Button(
                onClick = onClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = accentColor,
                    contentColor = TextOnNeon
                ),
                modifier = Modifier.height(38.dp)
            ) {
                Text("SPIN", fontWeight = FontWeight.ExtraBold, fontSize = 12.sp)
            }
        }
    }
}
