package com.example.ui.screens.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.T999ViewModel

@Composable
fun AuthScreen(
    viewModel: T999ViewModel,
    onAuthSuccess: () -> Unit,
    modifier: Modifier = Modifier
) {
    var phoneNumber by remember { mutableStateOf("9876543210") }
    var selectedCountryCode by remember { mutableStateOf("+91") }
    var isCountryDropdownOpen by remember { mutableStateOf(false) }
    var isOtpStep by remember { mutableStateOf(false) }
    var otpCode by remember { mutableStateOf("999999") }
    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val countryCodes = listOf(
        Pair("+91", "🇮🇳 India"),
        Pair("+92", "🇵🇰 Pakistan"),
        Pair("+971", "🇦🇪 UAE"),
        Pair("+1", "🇺🇸 USA"),
        Pair("+44", "🇬🇧 UK"),
        Pair("+966", "🇸🇦 Saudi Arabia"),
        Pair("+880", "🇧🇩 Bangladesh")
    )

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Spacer(modifier = Modifier.height(20.dp))

            // Brand Logo Box
            Box(
                modifier = Modifier
                    .size(88.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(
                        Brush.radialGradient(
                            listOf(NeonGreenSubtle, DarkCard)
                        )
                    )
                    .border(2.dp, NeonGreen, RoundedCornerShape(24.dp))
                    .shadow(20.dp, RoundedCornerShape(24.dp), ambientColor = NeonGreenBright, spotColor = NeonGreen),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "T999",
                    color = NeonGreenBright,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 1.sp
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "T999 SOCIAL CASINO",
                color = NeonGreenBright,
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.5.sp
            )

            Text(
                text = "Premium Neon Slots & Coin Gaming",
                color = TextSecondary,
                fontSize = 13.sp
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Main Auth Card
            GlowCard(
                borderColor = NeonGreenSubtle,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = if (isOtpStep) "VERIFY OTP" else "PHONE LOGIN",
                        color = NeonGreen,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )

                    Text(
                        text = if (isOtpStep) "Enter the 6-digit code sent to $selectedCountryCode $phoneNumber"
                        else "Enter your mobile number to sign in or register instantly",
                        color = TextSecondary,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp, bottom = 18.dp)
                    )

                    if (!isOtpStep) {
                        // Phone number input with Country code
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Country code picker box
                            Box {
                                Surface(
                                    color = DarkSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, DarkCardBorder),
                                    modifier = Modifier
                                        .height(56.dp)
                                        .clickable { isCountryDropdownOpen = true }
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 12.dp)
                                    ) {
                                        Text(
                                            text = selectedCountryCode,
                                            color = NeonGreen,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                        Icon(
                                            imageVector = Icons.Default.ArrowDropDown,
                                            contentDescription = null,
                                            tint = TextSecondary
                                        )
                                    }
                                }

                                DropdownMenu(
                                    expanded = isCountryDropdownOpen,
                                    onDismissRequest = { isCountryDropdownOpen = false },
                                    modifier = Modifier.background(DarkSurface)
                                ) {
                                    countryCodes.forEach { (code, name) ->
                                        DropdownMenuItem(
                                            text = { Text("$name ($code)", color = TextPrimary) },
                                            onClick = {
                                                selectedCountryCode = code
                                                isCountryDropdownOpen = false
                                            }
                                        )
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedTextField(
                                value = phoneNumber,
                                onValueChange = {
                                    phoneNumber = it.filter { ch -> ch.isDigit() }.take(12)
                                    errorMessage = null
                                },
                                label = { Text("Phone Number", color = TextSecondary) },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone, imeAction = ImeAction.Done),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedBorderColor = NeonGreen,
                                    unfocusedBorderColor = DarkCardBorder,
                                    focusedTextColor = TextPrimary,
                                    unfocusedTextColor = TextPrimary,
                                    cursorColor = NeonGreen
                                ),
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("phone_input")
                            )
                        }

                        Spacer(modifier = Modifier.height(20.dp))

                        NeonButton(
                            text = if (isLoading) "SENDING OTP..." else "GET OTP & LOGIN",
                            onClick = {
                                if (phoneNumber.length < 7) {
                                    errorMessage = "Please enter a valid phone number"
                                } else {
                                    isLoading = true
                                    isOtpStep = true
                                    isLoading = false
                                }
                            },
                            enabled = !isLoading && phoneNumber.isNotEmpty(),
                            icon = Icons.Default.Phone,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        // OTP Input Step
                        OutlinedTextField(
                            value = otpCode,
                            onValueChange = {
                                otpCode = it.filter { ch -> ch.isDigit() }.take(6)
                                errorMessage = null
                            },
                            label = { Text("6-Digit OTP Code", color = TextSecondary) },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number, imeAction = ImeAction.Done),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = NeonGreen
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("otp_input")
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Code: 999999 (Auto-filled)",
                                color = TextMuted,
                                fontSize = 11.sp
                            )
                            TextButton(onClick = { isOtpStep = false }) {
                                Text("Change Phone", color = CyberCyan, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        NeonButton(
                            text = if (isLoading) "VERIFYING..." else "CONFIRM & ENTER APP",
                            onClick = {
                                isLoading = true
                                viewModel.login(phoneNumber, selectedCountryCode) { success ->
                                    isLoading = false
                                    if (success) {
                                        onAuthSuccess()
                                    }
                                }
                            },
                            enabled = !isLoading && otpCode.length >= 4,
                            icon = Icons.Default.CheckCircle,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (errorMessage != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = errorMessage ?: "",
                            color = AlertRed,
                            fontSize = 12.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Quick Demo / Admin Switcher Card
            GlowCard(
                borderColor = DarkCardBorder,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "QUICK DEMO ACCOUNTS",
                        color = GoldAccent,
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        CyberOutlinedButton(
                            text = "Demo Player",
                            onClick = {
                                phoneNumber = "9876543210"
                                selectedCountryCode = "+91"
                                viewModel.login("9876543210", "+91") { onAuthSuccess() }
                            },
                            icon = Icons.Default.PlayArrow,
                            borderColor = NeonGreen,
                            textColor = NeonGreen,
                            modifier = Modifier.weight(1f)
                        )

                        CyberOutlinedButton(
                            text = "Admin Mode",
                            onClick = {
                                phoneNumber = "9999999999"
                                selectedCountryCode = "+91"
                                viewModel.login("9999999999", "+91") { onAuthSuccess() }
                            },
                            icon = Icons.Default.AdminPanelSettings,
                            borderColor = GoldAccent,
                            textColor = GoldAccent,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            VirtualCurrencyDisclaimerCard()

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
