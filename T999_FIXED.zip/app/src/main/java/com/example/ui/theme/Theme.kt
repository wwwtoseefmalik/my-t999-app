package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val T999ColorScheme = darkColorScheme(
    primary = NeonGreen,
    onPrimary = TextOnNeon,
    primaryContainer = NeonGreenSubtle,
    onPrimaryContainer = NeonGreenBright,
    secondary = CyberCyan,
    onSecondary = TextOnNeon,
    secondaryContainer = DarkSurfaceVariant,
    onSecondaryContainer = CyberCyan,
    tertiary = GoldAccent,
    onTertiary = TextOnNeon,
    tertiaryContainer = DarkSurfaceVariant,
    onTertiaryContainer = GoldAccent,
    background = DarkBackground,
    onBackground = TextPrimary,
    surface = DarkSurface,
    onSurface = TextPrimary,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = TextSecondary,
    outline = DarkCardBorder,
    outlineVariant = NeonGreenSubtle,
    error = AlertRed,
    onError = TextPrimary
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = T999ColorScheme,
        typography = Typography,
        content = content
    )
}

