package com.example.ui.screens.wallet

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CoinTransactionEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.StatusBadge
import com.example.ui.components.TopAppHeader
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun WalletScreen(
    viewModel: T999ViewModel,
    onNavigateToRecharge: () -> Unit,
    initialTab: Int = 0,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val transactions by viewModel.userTransactions.collectAsState()
    val paymentRequests by viewModel.userPayments.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(initialTab) }
    val tabs = listOf("Coin History", "Payment Status")

    val formattedBalance = NumberFormat.getNumberInstance(Locale.US).format(currentUser?.coinBalance ?: 0L)
    val formattedPurchased = NumberFormat.getNumberInstance(Locale.US).format(currentUser?.totalPurchasedCoins ?: 0L)
    val formattedUsed = NumberFormat.getNumberInstance(Locale.US).format(currentUser?.totalUsedCoins ?: 0L)
    val formattedBonus = NumberFormat.getNumberInstance(Locale.US).format(currentUser?.totalBonusCoins ?: 0L)

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Header
            item {
                TopAppHeader(
                    currentUser = currentUser,
                    onBuyCoinsClick = onNavigateToRecharge,
                    onProfileClick = {},
                    onNotificationsClick = {},
                    onSoundToggle = { viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled },
                    isSoundOn = viewModel.soundManager.isSoundEnabled
                )
            }

            // Wallet Master Balance Card
            item {
                GlowCard(
                    glowColor = NeonGreenBright,
                    borderColor = NeonGreen,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "TOTAL AVAILABLE COINS",
                            color = TextSecondary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(text = "💰", fontSize = 28.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = formattedBalance,
                                color = GoldAccent,
                                fontWeight = FontWeight.Black,
                                fontSize = 32.sp,
                                letterSpacing = 1.sp
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "T999",
                                color = NeonGreenBright,
                                fontWeight = FontWeight.Black,
                                fontSize = 16.sp
                            )
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Recharge Button
                        NeonButton(
                            text = "RECHARGE T999 COINS",
                            onClick = onNavigateToRecharge,
                            icon = Icons.Default.Add,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }

            // Wallet Stats Breakdown Grid
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Total Purchased
                    WalletStatTile(
                        title = "Purchased",
                        value = formattedPurchased,
                        icon = "💳",
                        color = CyberCyan,
                        modifier = Modifier.weight(1f)
                    )

                    // Used in Games
                    WalletStatTile(
                        title = "Used in Slots",
                        value = formattedUsed,
                        icon = "🎰",
                        color = AlertRed,
                        modifier = Modifier.weight(1f)
                    )

                    // Daily & Bonus
                    WalletStatTile(
                        title = "Bonus Won",
                        value = formattedBonus,
                        icon = "🎁",
                        color = GoldAccent,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Tab Selector
            item {
                Spacer(modifier = Modifier.height(18.dp))
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = DarkSurface,
                    contentColor = NeonGreenBright,
                    edgePadding = 16.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = NeonGreen
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = {
                                selectedTabIndex = index
                                viewModel.soundManager.playButtonClick()
                            },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 14.sp,
                                    color = if (selectedTabIndex == index) NeonGreenBright else TextSecondary
                                )
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Tab 1: Coin Transactions
            if (selectedTabIndex == 0) {
                if (transactions.isEmpty()) {
                    item {
                        EmptyHistoryView(message = "No coin transactions yet. Spin slots or claim bonuses!")
                    }
                } else {
                    items(transactions) { tx ->
                        TransactionRow(tx = tx)
                    }
                }
            }

            // Tab 2: Payment Requests & Status
            if (selectedTabIndex == 1) {
                if (paymentRequests.isEmpty()) {
                    item {
                        EmptyHistoryView(message = "No recharge requests yet. Tap 'Buy Coins' to start.")
                    }
                } else {
                    items(paymentRequests) { payment ->
                        PaymentRequestRow(payment = payment)
                    }
                }
            }

            // Virtual Currency Notice
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    VirtualCurrencyDisclaimerCard()
                }
            }
        }
    }
}

@Composable
fun WalletStatTile(
    title: String,
    value: String,
    icon: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    GlowCard(
        glowColor = color,
        borderColor = color.copy(alpha = 0.3f),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(text = icon, fontSize = 18.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = title, color = TextSecondary, fontSize = 10.sp, fontWeight = FontWeight.Medium)
            Text(
                text = value,
                color = color,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun TransactionRow(tx: CoinTransactionEntity) {
    val isCredit = tx.amount > 0
    val formattedTime = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(tx.timestamp))

    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(if (isCredit) NeonGreenSubtle else Color(0xFF330B14))
                        .border(1.dp, if (isCredit) NeonGreen else AlertRed, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                        contentDescription = null,
                        tint = if (isCredit) NeonGreenBright else AlertRed,
                        modifier = Modifier.size(18.dp)
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = tx.description,
                        color = TextPrimary,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formattedTime,
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Text(
                text = "${if (isCredit) "+" else ""}${tx.amount} Coins",
                color = if (isCredit) NeonGreenBright else AlertRed,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun PaymentRequestRow(payment: PaymentRequestEntity) {
    val formattedDate = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(payment.createdAt))

    GlowCard(
        borderColor = when (payment.status) {
            "Successful" -> NeonGreenSubtle
            "Pending" -> DarkCardBorder
            "Rejected", "Failed" -> AlertRed.copy(alpha = 0.5f)
            else -> DarkCardBorder
        },
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("💳", fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "+${payment.coins} T999 Coins",
                            color = GoldAccent,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp
                        )
                        Text(
                            text = "Paid Rs. ${payment.priceRs.toInt()} via ${payment.paymentMethod}",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }
                }

                StatusBadge(status = payment.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(
                color = DarkSurfaceVariant,
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Ref: ${payment.transactionRefId}",
                        color = TextPrimary,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "TILL: ${payment.tillId}",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = formattedDate,
                    color = TextMuted,
                    fontSize = 10.sp
                )
                if (payment.adminNotes != null) {
                    Text(
                        text = "Note: ${payment.adminNotes}",
                        color = WarningOrange,
                        fontSize = 10.sp,
                        maxLines = 1
                    )
                }
            }
        }
    }
}

@Composable
fun EmptyHistoryView(message: String) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = "📜", fontSize = 36.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = message,
                color = TextSecondary,
                fontSize = 13.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}
