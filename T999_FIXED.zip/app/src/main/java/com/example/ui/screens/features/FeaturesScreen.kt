package com.example.ui.screens.features

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.MilitaryTech
import androidx.compose.material.icons.filled.Redeem
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.UserEntity
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.TopAppHeader
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun FeaturesScreen(
    viewModel: T999ViewModel,
    initialTab: Int = 0,
    onNavigateToRecharge: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val luckyWheelState by viewModel.luckyWheelState.collectAsState()

    var selectedTabIndex by remember { mutableIntStateOf(initialTab) }
    val tabs = listOf("Daily Bonus", "Lucky Wheel", "Promo Codes", "Leaderboard", "Refer & Earn")

    var promoInput by remember { mutableStateOf("") }
    val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
    val isBonusClaimedToday = currentUser?.lastDailyBonusClaimDate == todayStr

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Header
            item {
                TopAppHeader(
                    currentUser = currentUser,
                    onBuyCoinsClick = onNavigateToRecharge,
                    onProfileClick = {},
                    onNotificationsClick = {},
                    onSoundToggle = { viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled },
                    isSoundOn = viewModel.soundManager.isSoundEnabled
                )
            }

            // Tab Row
            item {
                ScrollableTabRow(
                    selectedTabIndex = selectedTabIndex,
                    containerColor = DarkSurface,
                    contentColor = NeonGreenBright,
                    edgePadding = 16.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                            color = NeonGreen
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTabIndex == index,
                            onClick = {
                                selectedTabIndex = index
                                viewModel.soundManager.playButtonClick()
                            },
                            text = {
                                Text(
                                    text = title,
                                    fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp,
                                    color = if (selectedTabIndex == index) NeonGreenBright else TextSecondary
                                )
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }

            // 1. DAILY BONUS TAB
            if (selectedTabIndex == 0) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        GlowCard(
                            glowColor = GoldGlow,
                            borderColor = GoldAccent,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "7-DAY STREAK BONUS",
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Login daily to level up your T999 Coin rewards!",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                // 7 Day Progress Tiles
                                val streakDays = listOf(50L, 100L, 150L, 200L, 300L, 500L, 1000L)
                                val currentStreak = currentUser?.dailyStreak ?: 1

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    streakDays.forEachIndexed { index, coins ->
                                        val day = index + 1
                                        val isCurrent = day == currentStreak
                                        val isCompleted = day < currentStreak

                                        Column(
                                            horizontalAlignment = Alignment.CenterHorizontally,
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Box(
                                                modifier = Modifier
                                                    .size(36.dp)
                                                    .clip(RoundedCornerShape(8.dp))
                                                    .background(
                                                        if (isCurrent) NeonGreenSubtle
                                                        else if (isCompleted) DarkSurfaceVariant
                                                        else DarkSurface
                                                    )
                                                    .border(
                                                        1.dp,
                                                        if (isCurrent) GoldAccent else DarkCardBorder,
                                                        RoundedCornerShape(8.dp)
                                                    ),
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(
                                                    text = if (isCompleted) "✓" else if (day == 7) "👑" else "🎁",
                                                    fontSize = 14.sp,
                                                    color = if (isCompleted) NeonGreenBright else GoldAccent
                                                )
                                            }
                                            Spacer(modifier = Modifier.height(4.dp))
                                            Text(
                                                text = "D$day",
                                                color = if (isCurrent) GoldAccent else TextMuted,
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                            Text(
                                                text = "+$coins",
                                                color = if (isCurrent) NeonGreenBright else TextSecondary,
                                                fontSize = 9.sp
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                NeonButton(
                                    text = if (isBonusClaimedToday) "CLAIMED FOR TODAY (COME BACK TOMORROW)" else "CLAIM DAY $currentStreak BONUS NOW",
                                    onClick = { viewModel.claimDailyBonus() },
                                    enabled = !isBonusClaimedToday,
                                    icon = Icons.Default.CardGiftcard,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // 2. LUCKY WHEEL TAB
            if (selectedTabIndex == 1) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        GlowCard(
                            glowColor = ElectricPurple,
                            borderColor = ElectricPurple,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = "LUCKY PRIZE WHEEL",
                                    color = NeonGreenBright,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp,
                                    letterSpacing = 1.sp
                                )
                                Text(
                                    text = "Free Spins Available: ${currentUser?.luckySpinsRemaining ?: 0}",
                                    color = GoldAccent,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Spacer(modifier = Modifier.height(18.dp))

                                // Rotating Wheel Graphic Container
                                Box(
                                    modifier = Modifier
                                        .size(190.dp)
                                        .rotate(luckyWheelState.rotationAngle)
                                        .clip(CircleShape)
                                        .background(
                                            Brush.sweepGradient(
                                                listOf(
                                                    NeonGreenSubtle,
                                                    DarkCard,
                                                    Color(0xFF2C1654),
                                                    DarkCard,
                                                    NeonGreenSubtle
                                                )
                                            )
                                        )
                                        .border(3.dp, Brush.sweepGradient(listOf(NeonGreen, GoldAccent, CyberCyan, NeonGreen)), CircleShape),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("🎡", fontSize = 48.sp)
                                        Text("T999", color = NeonGreenBright, fontWeight = FontWeight.Black, fontSize = 14.sp)
                                    }
                                }

                                Spacer(modifier = Modifier.height(20.dp))

                                if (luckyWheelState.lastWonCoins != null) {
                                    Text(
                                        text = "🎉 YOU WON +${luckyWheelState.lastWonCoins} T999 COINS!",
                                        color = GoldAccent,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 15.sp
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                }

                                NeonButton(
                                    text = if (luckyWheelState.isSpinning) "SPINNING WHEEL..."
                                    else if ((currentUser?.luckySpinsRemaining ?: 0) > 0) "SPIN FREE (${currentUser?.luckySpinsRemaining} REMAINING)"
                                    else "SPIN FOR 50 COINS",
                                    onClick = { viewModel.spinLuckyWheel {} },
                                    enabled = !luckyWheelState.isSpinning,
                                    icon = Icons.Default.Casino,
                                    containerColor = ElectricPurple,
                                    contentColor = TextPrimary,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }

            // 3. PROMO CODES TAB
            if (selectedTabIndex == 2) {
                item {
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        GlowCard(
                            borderColor = DarkCardBorder,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(18.dp)
                            ) {
                                Text(
                                    text = "REDEEM PROMO CODE",
                                    color = NeonGreenBright,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Enter your secret promo coupon code to unlock free T999 Coins.",
                                    color = TextSecondary,
                                    fontSize = 12.sp
                                )

                                Spacer(modifier = Modifier.height(14.dp))

                                OutlinedTextField(
                                    value = promoInput,
                                    onValueChange = { promoInput = it.uppercase() },
                                    label = { Text("Enter Promo Code (e.g. T999WELCOME)", color = TextSecondary) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkCardBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary,
                                        cursorColor = NeonGreen
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("promo_code_input")
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                NeonButton(
                                    text = "REDEEM CODE",
                                    onClick = {
                                        viewModel.redeemPromoCode(promoInput) {
                                            promoInput = ""
                                        }
                                    },
                                    enabled = promoInput.isNotBlank(),
                                    icon = Icons.Default.Redeem,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Sample Active Codes to try
                        GlowCard(borderColor = NeonGreenSubtle, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text("AVAILABLE COMMUNITY CODES", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("T999WELCOME", color = NeonGreenBright, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                    Text("+100 Coins", color = TextPrimary, fontSize = 12.sp)
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text("NEON999", color = NeonGreenBright, fontWeight = FontWeight.Black, fontFamily = FontFamily.Monospace)
                                    Text("+150 Coins", color = TextPrimary, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }

            // 4. LEADERBOARD TAB
            if (selectedTabIndex == 3) {
                item {
                    Text(
                        text = "TOP T999 COIN TITANS",
                        color = GoldAccent,
                        fontWeight = FontWeight.Black,
                        fontSize = 15.sp,
                        letterSpacing = 1.sp,
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                    )
                }

                itemsIndexed(allUsers) { index, user ->
                    LeaderboardUserRow(rank = index + 1, user = user, isSelf = user.id == currentUser?.id)
                }
            }

            // 5. REFER & EARN TAB
            if (selectedTabIndex == 4) {
                item {
                    val inviteCode = currentUser?.inviteCode ?: "T999VIP"
                    Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                        GlowCard(
                            glowColor = NeonGreen,
                            borderColor = NeonGreen,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text("🤝", fontSize = 32.sp)
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "INVITE FRIENDS & EARN COINS",
                                    color = NeonGreenBright,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = "Share your unique code. Get +50 T999 Bonus Coins every time an invited friend recharges!",
                                    color = TextSecondary,
                                    fontSize = 12.sp,
                                    textAlign = TextAlign.Center
                                )

                                Spacer(modifier = Modifier.height(16.dp))

                                Surface(
                                    color = DarkSurfaceVariant,
                                    shape = RoundedCornerShape(12.dp),
                                    border = BorderStroke(1.dp, NeonGreenSubtle),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 16.dp, vertical = 12.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text("YOUR REFERRAL CODE", color = TextMuted, fontSize = 10.sp)
                                            Text(
                                                text = inviteCode,
                                                color = GoldAccent,
                                                fontWeight = FontWeight.Black,
                                                fontSize = 20.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }

                                        Button(
                                            onClick = {
                                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                                clipboard.setPrimaryClip(ClipData.newPlainText("Invite Code", inviteCode))
                                                viewModel.soundManager.playButtonClick()
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(
                                                containerColor = NeonGreen,
                                                contentColor = TextOnNeon
                                            )
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("COPY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Virtual Currency Notice
            item {
                Spacer(modifier = Modifier.height(20.dp))
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    VirtualCurrencyDisclaimerCard()
                }
            }
        }
    }
}

@Composable
fun LeaderboardUserRow(rank: Int, user: UserEntity, isSelf: Boolean) {
    val rankBadge = when (rank) {
        1 -> "🥇"
        2 -> "🥈"
        3 -> "🥉"
        else -> "#$rank"
    }

    Surface(
        color = if (isSelf) NeonGreenSubtle else DarkSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isSelf) NeonGreen else DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = rankBadge,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = GoldAccent,
                    modifier = Modifier.width(36.dp)
                )

                Box(
                    modifier = Modifier
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant)
                        .border(1.dp, if (isSelf) NeonGreen else DarkCardBorder, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (user.isAdmin) "👑" else "🎮",
                        fontSize = 16.sp
                    )
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column {
                    Text(
                        text = "${user.userName}${if (isSelf) " (You)" else ""}",
                        color = if (isSelf) NeonGreenBright else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "Streak: ${user.dailyStreak} Days",
                        color = TextMuted,
                        fontSize = 10.sp
                    )
                }
            }

            Text(
                text = "${NumberFormat.getNumberInstance(Locale.US).format(user.coinBalance)} Coins",
                color = GoldAccent,
                fontWeight = FontWeight.Black,
                fontSize = 14.sp
            )
        }
    }
}
