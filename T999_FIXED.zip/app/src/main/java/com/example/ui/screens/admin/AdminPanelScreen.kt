package com.example.ui.screens.admin

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CoinPackageEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.data.entity.UserEntity
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.StatusBadge
import com.example.ui.components.TopAppHeader
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun AdminPanelScreen(
    viewModel: T999ViewModel,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val allPayments by viewModel.allPayments.collectAsState()
    val allUsers by viewModel.allUsers.collectAsState()
    val allPackages by viewModel.allPackages.collectAsState()
    val configs by viewModel.configs.collectAsState()

    var selectedTab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Pending Payments", "All Payments", "Users", "Packages", "Settings")

    // State for Add Package Dialog
    var isAddPackageDialogOpen by remember { mutableStateOf(false) }
    var newPackageCoins by remember { mutableStateOf("1000") }
    var newPackagePrice by remember { mutableStateOf("1000") }
    var newPackageTag by remember { mutableStateOf("VIP DEAL") }

    // State for Config Edit
    var tillIdConfig by remember { mutableStateOf(configs["till_id"] ?: "990666708") }
    var paymentMethodConfig by remember { mutableStateOf(configs["payment_method"] ?: "TILL Payment") }
    var announcementConfig by remember { mutableStateOf(configs["announcement"] ?: "Welcome to T999 Social Gaming!") }

    // State for User Bonus Modal
    var selectedUserForBonus by remember { mutableStateOf<UserEntity?>(null) }
    var bonusCoinAmount by remember { mutableStateOf("500") }

    val pendingPayments = allPayments.filter { it.status == "Pending" }

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Header
            item {
                TopAppHeader(
                    currentUser = currentUser,
                    onBuyCoinsClick = {},
                    onProfileClick = {},
                    onNotificationsClick = {},
                    onSoundToggle = { viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled },
                    isSoundOn = viewModel.soundManager.isSoundEnabled
                )
            }

            // Screen Title & Stats
            item {
                Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = GoldAccent)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "T999 ADMIN MASTER PANEL",
                            color = GoldAccent,
                            fontWeight = FontWeight.Black,
                            fontSize = 18.sp,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "Real-time payment verification, user balances & store packages",
                        color = TextSecondary,
                        fontSize = 12.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    // 4 Stat Counters
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AdminStatCard("Pending", "${pendingPayments.size}", WarningOrange, Modifier.weight(1f))
                        AdminStatCard("All Txns", "${allPayments.size}", CyberCyan, Modifier.weight(1f))
                        AdminStatCard("Users", "${allUsers.size}", NeonGreenBright, Modifier.weight(1f))
                        AdminStatCard("Packages", "${allPackages.size}", GoldAccent, Modifier.weight(1f))
                    }
                }
            }

            // Tab Bar
            item {
                Spacer(modifier = Modifier.height(6.dp))
                ScrollableTabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurface,
                    contentColor = GoldAccent,
                    edgePadding = 16.dp,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldAccent
                        )
                    }
                ) {
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = selectedTab == index,
                            onClick = {
                                selectedTab = index
                                viewModel.soundManager.playButtonClick()
                            },
                            text = {
                                Text(
                                    text = if (index == 0 && pendingPayments.isNotEmpty()) "$title (${pendingPayments.size})" else title,
                                    fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                                    fontSize = 13.sp,
                                    color = if (selectedTab == index) GoldAccent else TextSecondary
                                )
                            }
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // TAB 0: PENDING PAYMENTS
            if (selectedTab == 0) {
                if (pendingPayments.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text("No pending TILL payment verification requests.", color = TextSecondary)
                        }
                    }
                } else {
                    items(pendingPayments) { payment ->
                        AdminPaymentApprovalCard(
                            payment = payment,
                            onApprove = { viewModel.adminApprovePayment(payment.id) },
                            onReject = { viewModel.adminRejectPayment(payment.id) },
                            onSetStatus = { status -> viewModel.adminSetPaymentStatus(payment.id, status, "Admin manual status override") }
                        )
                    }
                }
            }

            // TAB 1: ALL PAYMENTS
            if (selectedTab == 1) {
                if (allPayments.isEmpty()) {
                    item {
                        Box(modifier = Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) {
                            Text("No payment requests registered.", color = TextSecondary)
                        }
                    }
                } else {
                    items(allPayments) { payment ->
                        AdminPaymentApprovalCard(
                            payment = payment,
                            onApprove = { viewModel.adminApprovePayment(payment.id) },
                            onReject = { viewModel.adminRejectPayment(payment.id) },
                            onSetStatus = { status -> viewModel.adminSetPaymentStatus(payment.id, status, "Admin status update") }
                        )
                    }
                }
            }

            // TAB 2: USERS MANAGEMENT
            if (selectedTab == 2) {
                items(allUsers) { user ->
                    AdminUserRow(
                        user = user,
                        isCurrent = user.id == currentUser?.id,
                        onSwitchToUser = { viewModel.switchUser(user.id) },
                        onGrantBonus = { selectedUserForBonus = user }
                    )
                }
            }

            // TAB 3: PACKAGE MANAGEMENT
            if (selectedTab == 3) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Active Store Coin Packages", color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Button(
                            onClick = { isAddPackageDialogOpen = true },
                            colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = TextOnNeon),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("ADD PACKAGE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }

                items(allPackages) { pkg ->
                    AdminPackageRow(
                        pkg = pkg,
                        onDelete = { viewModel.adminDeletePackage(pkg.id) }
                    )
                }
            }

            // TAB 4: SETTINGS & CONFIGURATION
            if (selectedTab == 4) {
                item {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        GlowCard(borderColor = DarkCardBorder, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("TILL PAYMENT GATEWAY CONFIG", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = tillIdConfig,
                                    onValueChange = { tillIdConfig = it },
                                    label = { Text("TILL ID Number", color = TextSecondary) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkCardBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = paymentMethodConfig,
                                    onValueChange = { paymentMethodConfig = it },
                                    label = { Text("Payment Method Name", color = TextSecondary) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkCardBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                NeonButton(
                                    text = "SAVE PAYMENT CONFIG",
                                    onClick = {
                                        viewModel.adminUpdateConfig("till_id", tillIdConfig)
                                        viewModel.adminUpdateConfig("payment_method", paymentMethodConfig)
                                    },
                                    icon = Icons.Default.Settings,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }

                        GlowCard(borderColor = DarkCardBorder, modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text("LOBBY ANNOUNCEMENT", color = NeonGreenBright, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                Spacer(modifier = Modifier.height(10.dp))

                                OutlinedTextField(
                                    value = announcementConfig,
                                    onValueChange = { announcementConfig = it },
                                    label = { Text("Ticker Announcement Text", color = TextSecondary) },
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedBorderColor = NeonGreen,
                                        unfocusedBorderColor = DarkCardBorder,
                                        focusedTextColor = TextPrimary,
                                        unfocusedTextColor = TextPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth()
                                )

                                Spacer(modifier = Modifier.height(12.dp))

                                NeonButton(
                                    text = "UPDATE ANNOUNCEMENT",
                                    onClick = {
                                        viewModel.adminUpdateConfig("announcement", announcementConfig)
                                    },
                                    icon = Icons.Default.CheckCircle,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }
                }
            }
        }

        // Add Package Dialog
        if (isAddPackageDialogOpen) {
            AlertDialog(
                onDismissRequest = { isAddPackageDialogOpen = false },
                containerColor = DarkSurface,
                title = { Text("ADD NEW COIN PACKAGE", color = GoldAccent, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Rule: Package coins must be >= 100.", color = TextSecondary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = newPackageCoins,
                            onValueChange = { newPackageCoins = it },
                            label = { Text("Coin Amount (Min 100)", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newPackagePrice,
                            onValueChange = { newPackagePrice = it },
                            label = { Text("Price in Rs.", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = newPackageTag,
                            onValueChange = { newPackageTag = it },
                            label = { Text("Badge Tag (e.g. VIP, HOT)", color = TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val coins = newPackageCoins.toLongOrNull() ?: 100L
                            val price = newPackagePrice.toDoubleOrNull() ?: 100.0
                            viewModel.adminAddPackage(coins, price, newPackageTag.ifBlank { null }, false) {
                                isAddPackageDialogOpen = false
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = TextOnNeon)
                    ) {
                        Text("SAVE PACKAGE")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { isAddPackageDialogOpen = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // Grant Bonus Modal
        if (selectedUserForBonus != null) {
            val user = selectedUserForBonus!!
            AlertDialog(
                onDismissRequest = { selectedUserForBonus = null },
                containerColor = DarkSurface,
                title = { Text("GRANT BONUS COINS", color = GoldAccent, fontWeight = FontWeight.Bold) },
                text = {
                    Column {
                        Text("Recipient: ${user.userName} (${user.phoneNumber})", color = TextPrimary, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))

                        OutlinedTextField(
                            value = bonusCoinAmount,
                            onValueChange = { bonusCoinAmount = it },
                            label = { Text("Bonus Coins Amount", color = TextSecondary) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val amount = bonusCoinAmount.toLongOrNull() ?: 500L
                            viewModel.adminGrantBonusCoins(user.id, amount, "Admin Promotional Gift")
                            selectedUserForBonus = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = TextOnNeon)
                    ) {
                        Text("CREDIT COINS")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { selectedUserForBonus = null }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun AdminStatCard(title: String, value: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(title, color = TextSecondary, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text(value, color = color, fontSize = 16.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
fun AdminPaymentApprovalCard(
    payment: PaymentRequestEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onSetStatus: (String) -> Unit
) {
    val formattedDate = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault()).format(Date(payment.createdAt))

    GlowCard(
        borderColor = if (payment.status == "Pending") WarningOrange else DarkCardBorder,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("User ID #${payment.userId}", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("+${payment.coins} T999 Coins (Rs. ${payment.priceRs.toInt()})", color = TextPrimary, fontWeight = FontWeight.Black, fontSize = 15.sp)
                }

                StatusBadge(status = payment.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Surface(color = DarkSurfaceVariant, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Transaction Ref: ${payment.transactionRefId}", color = NeonGreenBright, fontFamily = FontFamily.Monospace, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("TILL: ${payment.tillId} | Method: ${payment.paymentMethod}", color = TextSecondary, fontSize = 11.sp)
                    Text("Submitted: $formattedDate", color = TextMuted, fontSize = 10.sp)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onApprove,
                    colors = ButtonDefaults.buttonColors(containerColor = NeonGreen, contentColor = TextOnNeon),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("APPROVE", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }

                Button(
                    onClick = onReject,
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF330B14), contentColor = AlertRed),
                    border = BorderStroke(1.dp, AlertRed),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.weight(1f).height(38.dp)
                ) {
                    Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("REJECT", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                }
            }
        }
    }
}

@Composable
fun AdminUserRow(
    user: UserEntity,
    isCurrent: Boolean,
    onSwitchToUser: () -> Unit,
    onGrantBonus: () -> Unit
) {
    Surface(
        color = if (isCurrent) NeonGreenSubtle else DarkSurface,
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, if (isCurrent) NeonGreen else DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (user.isAdmin) "👑" else "👤", fontSize = 18.sp)
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "${user.userName} (#${user.id})",
                        color = if (isCurrent) NeonGreenBright else TextPrimary,
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp
                    )
                    Text(
                        text = "${user.countryCode} ${user.phoneNumber} | Balance: ${user.coinBalance} Coins",
                        color = GoldAccent,
                        fontSize = 11.sp
                    )
                }
            }

            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Button(
                    onClick = onGrantBonus,
                    colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = GoldAccent),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.height(32.dp)
                ) {
                    Text("+COINS", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }

                if (!isCurrent) {
                    Button(
                        onClick = onSwitchToUser,
                        colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceVariant, contentColor = CyberCyan),
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.height(32.dp)
                    ) {
                        Text("LOGIN", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun AdminPackageRow(pkg: CoinPackageEntity, onDelete: () -> Unit) {
    Surface(
        color = DarkSurface,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("${pkg.coins} T999 Coins", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text("Price: Rs. ${pkg.priceRs.toInt()} | Tag: ${pkg.tag ?: "None"}", color = TextSecondary, fontSize = 11.sp)
            }

            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = AlertRed)
            }
        }
    }
}
