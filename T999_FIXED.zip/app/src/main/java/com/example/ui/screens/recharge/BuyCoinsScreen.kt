package com.example.ui.screens.recharge

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.CoinPackageEntity
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.StatusBadge
import com.example.ui.components.TopAppHeader
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.WarningOrange
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuyCoinsScreen(
    viewModel: T999ViewModel,
    onNavigateToHistory: () -> Unit,
    onNavigateToWallet: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentUser by viewModel.currentUser.collectAsState()
    val packages by viewModel.activePackages.collectAsState()
    val configs by viewModel.configs.collectAsState()

    val tillId = configs["till_id"] ?: "990666708"
    val paymentMethod = configs["payment_method"] ?: "TILL Payment"
    val minRecharge = configs["min_recharge"] ?: "100"

    var selectedPackage by remember { mutableStateOf<CoinPackageEntity?>(null) }
    var isPaymentSheetOpen by remember { mutableStateOf(false) }
    var isRefIdDialogOpen by remember { mutableStateOf(false) }
    var transactionRefIdInput by remember { mutableStateOf("") }
    var submissionSuccessDialog by remember { mutableStateOf(false) }
    var inputError by remember { mutableStateOf<String?>(null) }

    // Filter packages: Strictly enforce rule (No package below 100 coins)
    val validPackages = packages.filter { it.coins >= 100L }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 100.dp)
        ) {
            // Header
            item {
                TopAppHeader(
                    currentUser = currentUser,
                    onBuyCoinsClick = {},
                    onProfileClick = {},
                    onNotificationsClick = onNavigateToWallet,
                    onSoundToggle = { viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled },
                    isSoundOn = viewModel.soundManager.isSoundEnabled
                )
            }

            // Screen Title & History Shortcut
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "BUY T999 COINS",
                            color = NeonGreenBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Official TILL Payment Gateway",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    CyberOutlinedButton(
                        text = "History",
                        onClick = onNavigateToHistory,
                        icon = Icons.Default.History,
                        borderColor = CyberCyan,
                        textColor = CyberCyan
                    )
                }
            }

            // Official Payment Method Info Card
            item {
                GlowCard(
                    glowColor = NeonGreen,
                    borderColor = NeonGreen.copy(alpha = 0.6f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(40.dp)
                                        .clip(RoundedCornerShape(10.dp))
                                        .background(NeonGreenSubtle)
                                        .border(1.dp, NeonGreen, RoundedCornerShape(10.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Payment, contentDescription = null, tint = NeonGreenBright)
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text("Payment Method", color = TextSecondary, fontSize = 11.sp)
                                    Text(paymentMethod, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                                }
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(NeonGreen.copy(alpha = 0.2f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text("SECURE", color = NeonGreenBright, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // TILL ID Display with Copy
                        Surface(
                            color = DarkSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text("TILL ID NUMBER", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                    Text(
                                        text = tillId,
                                        color = GoldAccent,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 20.sp,
                                        fontFamily = FontFamily.Monospace,
                                        letterSpacing = 1.5.sp
                                    )
                                }

                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        val clip = ClipData.newPlainText("TILL ID", tillId)
                                        clipboard.setPrimaryClip(clip)
                                        viewModel.soundManager.playButtonClick()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = NeonGreen,
                                        contentColor = TextOnNeon
                                    ),
                                    modifier = Modifier.testTag("copy_till_id_card_button")
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("COPY", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Minimum Recharge Notice
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = WarningOrange, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Minimum recharge: 100 T999 Coins for Rs.100",
                                color = WarningOrange,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            // Coin Packages Heading
            item {
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    text = "SELECT COIN PACKAGE",
                    color = NeonGreenBright,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    letterSpacing = 1.sp,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
                )
            }

            // Packages List
            items(validPackages) { pkg ->
                CoinPackageCard(
                    pkg = pkg,
                    isSelected = selectedPackage?.id == pkg.id,
                    onClick = {
                        selectedPackage = pkg
                        isPaymentSheetOpen = true
                        viewModel.soundManager.playButtonClick()
                    }
                )
            }

            // Verification & Safety Steps
            item {
                Spacer(modifier = Modifier.height(14.dp))
                GlowCard(
                    borderColor = DarkCardBorder,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text("HOW TO RECHARGE", color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(8.dp))
                        RechargeStepRow(step = "1", text = "Select coin package (Minimum 100 Coins / Rs.100)")
                        RechargeStepRow(step = "2", text = "Pay exact amount to TILL ID: $tillId")
                        RechargeStepRow(step = "3", text = "Click 'I Have Paid' and enter your Transaction / Reference ID")
                        RechargeStepRow(step = "4", text = "Coins credited automatically once payment is verified")
                    }
                }
            }

            // Virtual Currency Disclaimer
            item {
                Spacer(modifier = Modifier.height(16.dp))
                Box(modifier = Modifier.padding(horizontal = 16.dp)) {
                    VirtualCurrencyDisclaimerCard()
                }
            }
        }

        // Modal Bottom Sheet: Selected Package & Payment Details
        if (isPaymentSheetOpen && selectedPackage != null) {
            val pkg = selectedPackage!!
            ModalBottomSheet(
                onDismissRequest = { isPaymentSheetOpen = false },
                sheetState = sheetState,
                containerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "PAYMENT DETAILS",
                        color = NeonGreenBright,
                        fontWeight = FontWeight.Black,
                        fontSize = 18.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Package Summary Box
                    Surface(
                        color = DarkSurfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, NeonGreenSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("Selected Package", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    text = "${pkg.coins} T999 Coins",
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 18.sp
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Exact Price", color = TextSecondary, fontSize = 11.sp)
                                Text(
                                    text = "Rs. ${pkg.priceRs.toInt()}",
                                    color = NeonGreenBright,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 20.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // TILL ID Box
                    GlowCard(
                        glowColor = NeonGreen,
                        borderColor = NeonGreen,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                        ) {
                            Text("PAY TO TILL ID", color = TextSecondary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = tillId,
                                    color = GoldAccent,
                                    fontWeight = FontWeight.Black,
                                    fontSize = 22.sp,
                                    fontFamily = FontFamily.Monospace
                                )

                                Button(
                                    onClick = {
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("TILL ID", tillId))
                                        viewModel.soundManager.playButtonClick()
                                    },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = DarkSurfaceVariant,
                                        contentColor = NeonGreenBright
                                    ),
                                    border = BorderStroke(1.dp, NeonGreen)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("COPY TILL ID", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Action: I Have Paid Button
                    NeonButton(
                        text = "I HAVE PAID",
                        onClick = {
                            isPaymentSheetOpen = false
                            isRefIdDialogOpen = true
                            transactionRefIdInput = ""
                            inputError = null
                        },
                        icon = Icons.Default.CheckCircle,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Status will initially be 'Pending'. Coins will be credited after payment verification.",
                        color = TextMuted,
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        // Dialog: Enter Transaction Reference ID
        if (isRefIdDialogOpen && selectedPackage != null) {
            val pkg = selectedPackage!!
            AlertDialog(
                onDismissRequest = { isRefIdDialogOpen = false },
                containerColor = DarkSurface,
                title = {
                    Text(
                        text = "VERIFY PAYMENT",
                        color = NeonGreenBright,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                },
                text = {
                    Column {
                        Text(
                            text = "Package: ${pkg.coins} T999 Coins (Rs. ${pkg.priceRs.toInt()})\nTILL ID: $tillId",
                            color = TextSecondary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "Enter Transaction / Reference ID from your payment receipt:",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = transactionRefIdInput,
                            onValueChange = {
                                transactionRefIdInput = it
                                inputError = null
                            },
                            placeholder = { Text("e.g. TXN990666708X12", color = TextMuted) },
                            singleLine = true,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = NeonGreen,
                                unfocusedBorderColor = DarkCardBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary,
                                cursorColor = NeonGreen
                            ),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("transaction_ref_input")
                        )

                        if (inputError != null) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = inputError ?: "",
                                color = AlertRed,
                                fontSize = 11.sp
                            )
                        }
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (transactionRefIdInput.isBlank()) {
                                inputError = "Please enter your transaction reference ID"
                            } else {
                                viewModel.submitPayment(
                                    packageId = pkg.id,
                                    coinAmount = pkg.coins,
                                    priceRs = pkg.priceRs,
                                    paymentMethod = paymentMethod,
                                    tillId = tillId,
                                    transactionRefId = transactionRefIdInput
                                ) {
                                    isRefIdDialogOpen = false
                                    submissionSuccessDialog = true
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = TextOnNeon
                        ),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.testTag("submit_payment_button")
                    ) {
                        Text("SUBMIT FOR VERIFICATION", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { isRefIdDialogOpen = false }) {
                        Text("Cancel", color = TextSecondary)
                    }
                }
            )
        }

        // Dialog: Submission Confirmation
        if (submissionSuccessDialog) {
            AlertDialog(
                onDismissRequest = { submissionSuccessDialog = false },
                containerColor = DarkSurface,
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("🎉 ", fontSize = 20.sp)
                        Text("REQUEST SUBMITTED", color = NeonGreenBright, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    }
                },
                text = {
                    Column {
                        Text(
                            text = "Your recharge request has been recorded with status 'Pending'.",
                            color = TextPrimary,
                            fontSize = 13.sp
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Once admin approves the TILL transaction, ${selectedPackage?.coins} T999 Coins will be automatically credited to your wallet.",
                            color = TextSecondary,
                            fontSize = 12.sp
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            submissionSuccessDialog = false
                            onNavigateToHistory()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = NeonGreen,
                            contentColor = TextOnNeon
                        ),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("VIEW STATUS", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { submissionSuccessDialog = false }) {
                        Text("Done", color = TextSecondary)
                    }
                }
            )
        }
    }
}

@Composable
fun CoinPackageCard(
    pkg: CoinPackageEntity,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val borderColor = if (pkg.isPopular) NeonGreenBright else DarkCardBorder
    val glowColor = if (pkg.isPopular) NeonGreenBright else NeonGreen

    GlowCard(
        glowColor = glowColor,
        borderColor = borderColor,
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(
                            Brush.linearGradient(
                                listOf(DarkSurfaceVariant, if (pkg.isPopular) NeonGreenSubtle else DarkCard)
                            )
                        )
                        .border(1.dp, if (pkg.isPopular) NeonGreen else DarkCardBorder, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (pkg.coins >= 500) "💎" else if (pkg.coins >= 250) "💰" else "🪙", fontSize = 22.sp)
                }

                Spacer(modifier = Modifier.width(12.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "${pkg.coins} T999 Coins",
                            color = GoldAccent,
                            fontWeight = FontWeight.Black,
                            fontSize = 16.sp
                        )
                        if (pkg.tag != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(if (pkg.isPopular) NeonGreen else CyberCyan)
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = pkg.tag.uppercase(),
                                    color = TextOnNeon,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                    Text(
                        text = "1 Coin = Rs.1.00 Value",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }
            }

            Button(
                onClick = onClick,
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (pkg.isPopular) NeonGreen else DarkSurfaceVariant,
                    contentColor = if (pkg.isPopular) TextOnNeon else NeonGreenBright
                ),
                border = if (!pkg.isPopular) BorderStroke(1.dp, NeonGreen) else null,
                modifier = Modifier.height(40.dp)
            ) {
                Text(
                    text = "Rs. ${pkg.priceRs.toInt()}",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 13.sp
                )
            }
        }
    }
}

@Composable
fun RechargeStepRow(step: String, text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(18.dp)
                .clip(CircleShape)
                .background(NeonGreenSubtle)
                .border(1.dp, NeonGreen, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(text = step, color = NeonGreenBright, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = text, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp)
    }
}
