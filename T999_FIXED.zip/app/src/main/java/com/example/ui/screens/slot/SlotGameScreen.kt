package com.example.ui.screens.slot

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.entity.GameHistoryEntity
import com.example.data.repository.T999Repository.SlotSymbol
import com.example.ui.components.CoinBalanceChip
import com.example.ui.components.CyberOutlinedButton
import com.example.ui.components.GlowCard
import com.example.ui.components.NeonButton
import com.example.ui.components.VirtualCurrencyDisclaimerCard
import com.example.ui.theme.AlertRed
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCard
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.ElectricPurple
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.NeonGreenSubtle
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.T999ViewModel
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SlotGameScreen(
    viewModel: T999ViewModel,
    onNavigateToRecharge: () -> Unit,
    modifier: Modifier = Modifier
) {
    val currentUser by viewModel.currentUser.collectAsState()
    val slotState by viewModel.slotUiState.collectAsState()
    val gameHistory by viewModel.userGameHistory.collectAsState()

    var isPaytableOpen by remember { mutableStateOf(false) }
    var isHistoryOpen by remember { mutableStateOf(false) }
    var isAutoSpinSheetOpen by remember { mutableStateOf(false) }

    val betOptions = listOf(10L, 25L, 50L, 100L, 250L, 500L)
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    val infiniteTransition = rememberInfiniteTransition(label = "slot_pulse")
    val jackpotPulse by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "jackpot_scale"
    )

    Surface(
        color = DarkBackground,
        modifier = modifier.fillMaxSize()
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(bottom = 90.dp)
        ) {
            // Slot Header Bar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(NeonGreenSubtle)
                            .border(1.dp, NeonGreen, RoundedCornerShape(8.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("⚡", fontSize = 18.sp)
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "T999 NEON WILDS",
                            color = NeonGreenBright,
                            fontWeight = FontWeight.Black,
                            fontSize = 15.sp,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = "Fair Social Slot Engine",
                            color = TextMuted,
                            fontSize = 10.sp
                        )
                    }
                }

                // Balance Chip with Quick Buy
                CoinBalanceChip(
                    balance = currentUser?.coinBalance ?: 0L,
                    onAddClick = onNavigateToRecharge
                )
            }

            // Sub Navigation Bar (Controls & Rules)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Paytable
                    CyberOutlinedButton(
                        text = "Paytable",
                        onClick = { isPaytableOpen = true },
                        icon = Icons.Default.Info,
                        borderColor = DarkCardBorder,
                        textColor = TextSecondary,
                        modifier = Modifier.height(36.dp)
                    )

                    // History
                    CyberOutlinedButton(
                        text = "History",
                        onClick = { isHistoryOpen = true },
                        icon = Icons.Default.History,
                        borderColor = DarkCardBorder,
                        textColor = TextSecondary,
                        modifier = Modifier.height(36.dp)
                    )
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    // Turbo mode toggle
                    IconButton(
                        onClick = { viewModel.toggleTurboMode() },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Turbo",
                            tint = if (slotState.isTurboMode) GoldAccent else TextMuted
                        )
                    }

                    // Sound Toggle
                    IconButton(
                        onClick = {
                            viewModel.soundManager.isSoundEnabled = !viewModel.soundManager.isSoundEnabled
                        },
                        modifier = Modifier.size(36.dp)
                    ) {
                        Icon(
                            imageVector = if (viewModel.soundManager.isSoundEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                            contentDescription = "Sound",
                            tint = if (viewModel.soundManager.isSoundEnabled) NeonGreen else TextMuted
                        )
                    }
                }
            }

            // Main Slot Machine Box
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) {
                // Outer Machine Frame
                GlowCard(
                    glowColor = if (slotState.isMegaJackpot) GoldAccent else NeonGreen,
                    borderColor = if (slotState.isMegaJackpot) GoldAccent else NeonGreen,
                    shapeRadius = 24.dp,
                    modifier = Modifier.fillMaxSize()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp),
                        verticalArrangement = Arrangement.SpaceBetween,
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Jackpot Neon Bar
                        Surface(
                            color = DarkSurfaceVariant,
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (slotState.isMegaJackpot) GoldAccent else NeonGreenSubtle),
                            modifier = Modifier
                                .fillMaxWidth()
                                .then(if (slotState.isMegaJackpot) Modifier.scale(jackpotPulse) else Modifier)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("⚡", fontSize = 16.sp)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "MEGA JACKPOT",
                                        color = GoldAccent,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 13.sp,
                                        letterSpacing = 1.sp
                                    )
                                }

                                Text(
                                    text = "50x MULTIPLIER",
                                    color = NeonGreenBright,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // 3 Reel Display Window
                        Surface(
                            color = Color(0xFF060907),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(2.dp, Brush.verticalGradient(listOf(NeonGreen, DarkCardBorder))),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                SlotReelCell(
                                    symbol = slotState.reel1,
                                    isSpinning = slotState.isSpinning,
                                    modifier = Modifier.weight(1f)
                                )

                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(120.dp)
                                        .background(DarkCardBorder)
                                )

                                SlotReelCell(
                                    symbol = slotState.reel2,
                                    isSpinning = slotState.isSpinning,
                                    modifier = Modifier.weight(1f)
                                )

                                Box(
                                    modifier = Modifier
                                        .width(2.dp)
                                        .height(120.dp)
                                        .background(DarkCardBorder)
                                )

                                SlotReelCell(
                                    symbol = slotState.reel3,
                                    isSpinning = slotState.isSpinning,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Live Win / Result Banner
                        Surface(
                            color = if (slotState.lastWinCoins > 0) NeonGreenSubtle else DarkSurfaceVariant,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (slotState.lastWinCoins > 0) NeonGreen else DarkCardBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 8.dp, horizontal = 12.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Text(
                                    text = slotState.winDescription,
                                    color = if (slotState.lastWinCoins > 0) NeonGreenBright else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp,
                                    textAlign = TextAlign.Center
                                )

                                if (slotState.lastWinCoins > 0) {
                                    Text(
                                        text = "+${slotState.lastWinCoins} T999 COINS WON!",
                                        color = GoldAccent,
                                        fontWeight = FontWeight.Black,
                                        fontSize = 16.sp,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Controls (Bet Selector & Spin Button)
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurface)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Bet Selector Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "BET PER SPIN",
                        color = TextSecondary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        betOptions.forEach { bet ->
                            val isSelected = slotState.betAmount == bet
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) NeonGreen else DarkSurfaceVariant)
                                    .border(1.dp, if (isSelected) NeonGreenBright else DarkCardBorder, RoundedCornerShape(8.dp))
                                    .clickable { viewModel.setBetAmount(bet) }
                                    .padding(horizontal = 8.dp, vertical = 5.dp)
                            ) {
                                Text(
                                    text = "$bet",
                                    color = if (isSelected) TextOnNeon else TextPrimary,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Primary Spin Action Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Auto Spin Button
                    if (slotState.isAutoSpinActive) {
                        Button(
                            onClick = { viewModel.stopAutoSpin() },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AlertRed,
                                contentColor = TextPrimary
                            ),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .weight(1f)
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("STOP (${slotState.autoSpinsRemaining})", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    } else {
                        CyberOutlinedButton(
                            text = "AUTO",
                            onClick = { isAutoSpinSheetOpen = true },
                            icon = Icons.Default.Refresh,
                            borderColor = CyberCyan,
                            textColor = CyberCyan,
                            modifier = Modifier
                                .height(56.dp)
                                .width(90.dp)
                        )
                    }

                    // Main Spin Button
                    NeonButton(
                        text = if (slotState.isSpinning) "SPINNING..." else "SPIN (${slotState.betAmount} COINS)",
                        onClick = { viewModel.spinSlot() },
                        enabled = !slotState.isSpinning && !slotState.isAutoSpinActive,
                        icon = Icons.Default.PlayArrow,
                        modifier = Modifier
                            .height(56.dp)
                            .weight(2f)
                    )
                }
            }
        }

        // Paytable Bottom Sheet
        if (isPaytableOpen) {
            ModalBottomSheet(
                onDismissRequest = { isPaytableOpen = false },
                sheetState = sheetState,
                containerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "PAYTABLE & SYMBOL MULTIPLIERS",
                        color = NeonGreenBright,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    LazyColumn(
                        modifier = Modifier.fillMaxWidth().height(320.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        items(SlotSymbol.values().toList()) { sym ->
                            PaytableRow(symbol = sym)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "Fair RTP: 97.8% | Social Amusement Currency | 100% Virtual Coins",
                        color = TextMuted,
                        fontSize = 10.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }

        // Game History Bottom Sheet
        if (isHistoryOpen) {
            ModalBottomSheet(
                onDismissRequest = { isHistoryOpen = false },
                sheetState = sheetState,
                containerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "SLOT GAME HISTORY",
                        color = NeonGreenBright,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp,
                        letterSpacing = 1.sp
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    if (gameHistory.isEmpty()) {
                        Box(modifier = Modifier.fillMaxWidth().height(200.dp), contentAlignment = Alignment.Center) {
                            Text("No slot spins recorded yet.", color = TextSecondary)
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier.fillMaxWidth().height(320.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(gameHistory) { log ->
                                GameHistoryItem(log = log)
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }

        // Auto Spin Count Selector Sheet
        if (isAutoSpinSheetOpen) {
            ModalBottomSheet(
                onDismissRequest = { isAutoSpinSheetOpen = false },
                sheetState = sheetState,
                containerColor = DarkSurface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 12.dp)
                ) {
                    Text(
                        text = "SELECT AUTO SPINS",
                        color = NeonGreenBright,
                        fontWeight = FontWeight.Black,
                        fontSize = 16.sp
                    )
                    Spacer(modifier = Modifier.height(16.dp))

                    listOf(10, 25, 50).forEach { count ->
                        Button(
                            onClick = {
                                isAutoSpinSheetOpen = false
                                viewModel.startAutoSpin(count)
                            },
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = DarkSurfaceVariant,
                                contentColor = NeonGreenBright
                            ),
                            border = BorderStroke(1.dp, NeonGreen),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 6.dp)
                                .height(48.dp)
                        ) {
                            Text("$count Consecutive Spins", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(20.dp))
                }
            }
        }
    }
}

@Composable
fun SlotReelCell(
    symbol: SlotSymbol,
    isSpinning: Boolean,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .padding(4.dp)
            .fillMaxSize()
            .clip(RoundedCornerShape(12.dp))
            .background(DarkSurface)
            .border(1.dp, Color(symbol.colorHex).copy(alpha = 0.5f), RoundedCornerShape(12.dp)),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = symbol.icon,
                fontSize = 38.sp
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = symbol.title,
                color = Color(symbol.colorHex),
                fontWeight = FontWeight.Bold,
                fontSize = 10.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
fun PaytableRow(symbol: SlotSymbol) {
    Surface(
        color = DarkSurfaceVariant,
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(1.dp, DarkCardBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(text = symbol.icon, fontSize = 22.sp)
                Spacer(modifier = Modifier.width(10.dp))
                Text(text = symbol.title, color = TextPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }

            Text(
                text = "${symbol.multiplier3x.toInt()}x Multiplier",
                color = Color(symbol.colorHex),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun GameHistoryItem(log: GameHistoryEntity) {
    val formattedTime = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date(log.timestamp))
    val isWin = log.winAmount > 0

    Surface(
        color = DarkSurfaceVariant,
        shape = RoundedCornerShape(8.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("Bet: ${log.betAmount} Coins", color = TextSecondary, fontSize = 11.sp)
                Text(formattedTime, color = TextMuted, fontSize = 9.sp)
            }

            Text(
                text = if (isWin) "+${log.winAmount} Coins (${log.payoutMultiplier}x)" else "No Win (0)",
                color = if (isWin) NeonGreenBright else AlertRed,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp
            )
        }
    }
}
