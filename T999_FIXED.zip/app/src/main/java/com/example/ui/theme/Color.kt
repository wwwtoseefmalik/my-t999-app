package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// T999 Signature Neon Green & Dark Gaming Palette
val NeonGreen = Color(0xFF00FF66)
val NeonGreenBright = Color(0xFF39FF14)
val NeonGreenDark = Color(0xFF00B344)
val NeonGreenGlow = Color(0x6600FF66)
val NeonGreenSubtle = Color(0xFF0A331A)

val DarkBackground = Color(0xFF070A08)
val DarkSurface = Color(0xFF0F1511)
val DarkSurfaceVariant = Color(0xFF16201A)
val DarkCard = Color(0xFF131B16)
val DarkCardBorder = Color(0xFF1E3224)

val GoldAccent = Color(0xFFFFD700)
val GoldGlow = Color(0xFFFFB800)
val CyberCyan = Color(0xFF00F0FF)
val ElectricPurple = Color(0xFFB026FF)
val AlertRed = Color(0xFFFF3366)
val WarningOrange = Color(0xFFFF9900)

val TextPrimary = Color(0xFFF0FFF4)
val TextSecondary = Color(0xFF8FA896)
val TextMuted = Color(0xFF5A7262)
val TextOnNeon = Color(0xFF000000)

