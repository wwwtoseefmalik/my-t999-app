package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundManager
import com.example.data.database.T999Database
import com.example.data.entity.CoinPackageEntity
import com.example.data.entity.CoinTransactionEntity
import com.example.data.entity.GameHistoryEntity
import com.example.data.entity.NotificationEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.data.entity.UserEntity
import com.example.data.repository.T999Repository
import com.example.data.repository.T999Repository.SlotSymbol
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SlotUiState(
    val isSpinning: Boolean = false,
    val betAmount: Long = 50L,
    val reel1: SlotSymbol = SlotSymbol.T999_WILD,
    val reel2: SlotSymbol = SlotSymbol.NEON_SEVEN,
    val reel3: SlotSymbol = SlotSymbol.T999_WILD,
    val lastWinCoins: Long = 0L,
    val lastMultiplier: Double = 0.0,
    val isBigWin: Boolean = false,
    val isMegaJackpot: Boolean = false,
    val winDescription: String = "Place your bet & hit SPIN!",
    val isAutoSpinActive: Boolean = false,
    val autoSpinsRemaining: Int = 0,
    val isTurboMode: Boolean = false
)

data class LuckyWheelUiState(
    val isSpinning: Boolean = false,
    val rotationAngle: Float = 0f,
    val lastWonCoins: Long? = null
)

class T999ViewModel(application: Application) : AndroidViewModel(application) {

    private val database = T999Database.getDatabase(application, viewModelScope)
    val repository = T999Repository(database)
    val soundManager = SoundManager(application)

    // Current logged in user ID (default to 1 for seamless demo experience)
    private val _currentUserId = MutableStateFlow<Long?>(1L)
    val currentUserId = _currentUserId.asStateFlow()

    // Active User
    val currentUser: StateFlow<UserEntity?> = _currentUserId.flatMapLatest { id ->
        if (id != null) repository.getUserFlow(id) else flowOf(null)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allUsers: StateFlow<List<UserEntity>> = repository.getAllUsersFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Packages
    val activePackages: StateFlow<List<CoinPackageEntity>> = repository.getActivePackagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPackages: StateFlow<List<CoinPackageEntity>> = repository.getAllPackagesFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Payments
    val userPayments: StateFlow<List<PaymentRequestEntity>> = _currentUserId.flatMapLatest { id ->
        if (id != null) repository.getPaymentsByUserFlow(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allPayments: StateFlow<List<PaymentRequestEntity>> = repository.getAllPaymentsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Transactions
    val userTransactions: StateFlow<List<CoinTransactionEntity>> = _currentUserId.flatMapLatest { id ->
        if (id != null) repository.getTransactionsByUserFlow(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allTransactions: StateFlow<List<CoinTransactionEntity>> = repository.getAllTransactionsFlow()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Game History
    val userGameHistory: StateFlow<List<GameHistoryEntity>> = _currentUserId.flatMapLatest { id ->
        if (id != null) repository.getGameHistoryByUserFlow(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Notifications
    val notifications: StateFlow<List<NotificationEntity>> = _currentUserId.flatMapLatest { id ->
        if (id != null) repository.getNotificationsFlow(id) else flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Configs Map
    val configs: StateFlow<Map<String, String>> = repository.getAllConfigsFlow().map { list ->
        list.associate { it.key to it.value }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyMap())

    // UI States
    private val _slotUiState = MutableStateFlow(SlotUiState())
    val slotUiState: StateFlow<SlotUiState> = _slotUiState.asStateFlow()

    private val _luckyWheelState = MutableStateFlow(LuckyWheelUiState())
    val luckyWheelState: StateFlow<LuckyWheelUiState> = _luckyWheelState.asStateFlow()

    private val _uiEvents = MutableSharedFlow<String>()
    val uiEvents: SharedFlow<String> = _uiEvents.asSharedFlow()

    // Admin Mode toggle
    private val _isAdminModeActive = MutableStateFlow(false)
    val isAdminModeActive: StateFlow<Boolean> = _isAdminModeActive.asStateFlow()

    private var autoSpinJob: Job? = null

    init {
        // Ensure initial user exists or trigger welcome
        viewModelScope.launch {
            val user = repository.getUserById(1L)
            if (user == null) {
                repository.loginOrRegister("9876543210", "+91")
            }
        }
    }

    fun setAdminMode(active: Boolean) {
        _isAdminModeActive.value = active
    }

    fun logout() {
        _currentUserId.value = null
        _isAdminModeActive.value = false
        sendToast("Logged out successfully")
    }

    fun login(phoneNumber: String, countryCode: String, onComplete: (Boolean) -> Unit) {
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.loginOrRegister(phoneNumber, countryCode)
            result.onSuccess { user ->
                _currentUserId.value = user.id
                if (user.isAdmin) {
                    _isAdminModeActive.value = true
                }
                sendToast("Welcome ${user.userName}!")
                onComplete(true)
            }.onFailure { err ->
                sendToast(err.message ?: "Login failed")
                onComplete(false)
            }
        }
    }

    fun switchUser(userId: Long) {
        viewModelScope.launch {
            _currentUserId.value = userId
            val user = repository.getUserById(userId)
            if (user?.isAdmin == true) {
                _isAdminModeActive.value = true
            }
            sendToast("Switched to user: ${user?.userName}")
        }
    }

    // ---------------- SLOT MACHINE ACTIONS ----------------
    fun setBetAmount(amount: Long) {
        soundManager.playButtonClick()
        _slotUiState.update { it.copy(betAmount = amount) }
    }

    fun toggleTurboMode() {
        soundManager.playButtonClick()
        _slotUiState.update { it.copy(isTurboMode = !it.isTurboMode) }
    }

    fun startAutoSpin(count: Int) {
        soundManager.playButtonClick()
        _slotUiState.update { it.copy(isAutoSpinActive = true, autoSpinsRemaining = count) }
        autoSpinJob?.cancel()
        autoSpinJob = viewModelScope.launch {
            while (_slotUiState.value.isAutoSpinActive && _slotUiState.value.autoSpinsRemaining > 0) {
                val user = currentUser.value
                if (user == null || user.coinBalance < _slotUiState.value.betAmount) {
                    stopAutoSpin()
                    sendToast("Auto-spin stopped: Insufficient coins!")
                    break
                }
                executeSlotSpin()
                _slotUiState.update { it.copy(autoSpinsRemaining = it.autoSpinsRemaining - 1) }
                val delayMs = if (_slotUiState.value.isTurboMode) 1000L else 2200L
                delay(delayMs)
            }
            stopAutoSpin()
        }
    }

    fun stopAutoSpin() {
        autoSpinJob?.cancel()
        _slotUiState.update { it.copy(isAutoSpinActive = false, autoSpinsRemaining = 0) }
    }

    fun spinSlot() {
        if (_slotUiState.value.isSpinning) return
        soundManager.playButtonClick()
        viewModelScope.launch {
            executeSlotSpin()
        }
    }

    private suspend fun executeSlotSpin() {
        val user = currentUser.value ?: run {
            sendToast("Please login first")
            return
        }

        val bet = _slotUiState.value.betAmount
        if (user.coinBalance < bet) {
            sendToast("Not enough T999 Coins! Please recharge.")
            return
        }

        _slotUiState.update {
            it.copy(
                isSpinning = true,
                isBigWin = false,
                isMegaJackpot = false,
                winDescription = "Spinning reels..."
            )
        }

        val turbo = _slotUiState.value.isTurboMode
        val symbols = SlotSymbol.values()

        // Spin animation ticks
        val spinTicks = if (turbo) 6 else 14
        for (i in 0 until spinTicks) {
            soundManager.playSpinTick()
            _slotUiState.update {
                it.copy(
                    reel1 = symbols.random(),
                    reel2 = symbols.random(),
                    reel3 = symbols.random()
                )
            }
            delay(if (turbo) 60L else 110L)
        }

        // Calculate Result from Repository
        val spinResult = repository.playSlotSpin(user.id, bet)
        spinResult.onSuccess { result ->
            soundManager.playReelStop()

            _slotUiState.update {
                it.copy(
                    isSpinning = false,
                    reel1 = result.reel1,
                    reel2 = result.reel2,
                    reel3 = result.reel3,
                    lastWinCoins = result.winCoins,
                    lastMultiplier = result.winMultiplier,
                    isBigWin = result.winMultiplier >= 5.0 && !result.isJackpot,
                    isMegaJackpot = result.isJackpot,
                    winDescription = result.winLineDescription
                )
            }

            if (result.isJackpot) {
                soundManager.playJackpotSound(viewModelScope)
            } else if (result.winCoins > 0) {
                soundManager.playWinSound(viewModelScope)
            }
        }.onFailure { err ->
            _slotUiState.update { it.copy(isSpinning = false, winDescription = err.message ?: "Spin error") }
            sendToast(err.message ?: "Spin error")
        }
    }

    // ---------------- RECHARGE / BUY COINS ----------------
    fun submitPayment(
        packageId: Long,
        coinAmount: Long,
        priceRs: Double,
        paymentMethod: String,
        tillId: String,
        transactionRefId: String,
        onSuccess: () -> Unit
    ) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.submitPaymentRequest(
                userId = user.id,
                packageId = packageId,
                coinAmount = coinAmount,
                priceRs = priceRs,
                paymentMethod = paymentMethod,
                tillId = tillId,
                transactionRefId = transactionRefId
            )
            result.onSuccess {
                soundManager.playCoinClink()
                sendToast("Recharge request submitted! Status: Pending Verification.")
                onSuccess()
            }.onFailure { err ->
                sendToast(err.message ?: "Failed to submit payment request")
            }
        }
    }

    // ---------------- DAILY BONUS & LUCKY WHEEL ----------------
    fun claimDailyBonus() {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.claimDailyBonus(user.id)
            result.onSuccess { coins ->
                soundManager.playJackpotSound(viewModelScope)
                sendToast("Claimed Daily Bonus: +$coins T999 Coins!")
            }.onFailure { err ->
                sendToast(err.message ?: "Could not claim daily bonus")
            }
        }
    }

    fun spinLuckyWheel(onFinished: (Long) -> Unit) {
        val user = currentUser.value ?: return
        if (_luckyWheelState.value.isSpinning) return

        viewModelScope.launch {
            soundManager.playButtonClick()
            _luckyWheelState.update { it.copy(isSpinning = true, lastWonCoins = null) }

            // Animate wheel rotation
            val targetRotation = _luckyWheelState.value.rotationAngle + 1440f + (0..360).random().toFloat()
            for (step in 1..25) {
                soundManager.playSpinTick()
                val current = _luckyWheelState.value.rotationAngle + (targetRotation - _luckyWheelState.value.rotationAngle) * (step / 25f)
                _luckyWheelState.update { it.copy(rotationAngle = current) }
                delay(70)
            }

            val result = repository.playLuckySpin(user.id)
            result.onSuccess { coins ->
                _luckyWheelState.update { it.copy(isSpinning = false, lastWonCoins = coins) }
                soundManager.playWinSound(viewModelScope)
                sendToast("Lucky Spin Won: +$coins T999 Coins!")
                onFinished(coins)
            }.onFailure { err ->
                _luckyWheelState.update { it.copy(isSpinning = false) }
                sendToast(err.message ?: "Lucky spin failed")
            }
        }
    }

    // ---------------- PROMO CODE ----------------
    fun redeemPromoCode(code: String, onDone: () -> Unit) {
        val user = currentUser.value ?: return
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.redeemPromoCode(user.id, code)
            result.onSuccess { coins ->
                soundManager.playJackpotSound(viewModelScope)
                sendToast("Code Redeemed! +$coins T999 Coins credited!")
                onDone()
            }.onFailure { err ->
                sendToast(err.message ?: "Invalid promo code")
            }
        }
    }

    // ---------------- ADMIN MANAGEMENT ----------------
    fun adminApprovePayment(paymentId: Long, notes: String = "Verified by Admin") {
        viewModelScope.launch {
            soundManager.playCoinClink()
            val result = repository.updatePaymentStatus(paymentId, "Successful", notes)
            result.onSuccess {
                sendToast("Payment Approved & Coins Credited!")
            }.onFailure { err ->
                sendToast(err.message ?: "Failed to approve payment")
            }
        }
    }

    fun adminRejectPayment(paymentId: Long, notes: String = "Transaction verification failed") {
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.updatePaymentStatus(paymentId, "Rejected", notes)
            result.onSuccess {
                sendToast("Payment request marked Rejected.")
            }.onFailure { err ->
                sendToast(err.message ?: "Failed to reject payment")
            }
        }
    }

    fun adminSetPaymentStatus(paymentId: Long, status: String, notes: String?) {
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.updatePaymentStatus(paymentId, status, notes)
            result.onSuccess {
                sendToast("Status updated to $status")
            }.onFailure { err ->
                sendToast(err.message ?: "Update failed")
            }
        }
    }

    fun adminAddPackage(coins: Long, priceRs: Double, tag: String?, isPopular: Boolean, onDone: () -> Unit) {
        viewModelScope.launch {
            soundManager.playButtonClick()
            val result = repository.addCoinPackage(coins, priceRs, tag, isPopular)
            result.onSuccess {
                sendToast("Package added successfully!")
                onDone()
            }.onFailure { err ->
                sendToast(err.message ?: "Failed to add package")
            }
        }
    }

    fun adminDeletePackage(packageId: Long) {
        viewModelScope.launch {
            soundManager.playButtonClick()
            repository.deletePackage(packageId)
            sendToast("Package removed")
        }
    }

    fun adminUpdateConfig(key: String, value: String) {
        viewModelScope.launch {
            soundManager.playButtonClick()
            repository.updateAppConfig(key, value)
            sendToast("Configuration saved: $key")
        }
    }

    fun adminGrantBonusCoins(userId: Long, coins: Long, reason: String) {
        viewModelScope.launch {
            soundManager.playCoinClink()
            val result = repository.adminCreditUserCoins(userId, coins, reason)
            result.onSuccess {
                sendToast("Credited +$coins T999 Coins to user #$userId")
            }.onFailure { err ->
                sendToast(err.message ?: "Failed to grant coins")
            }
        }
    }

    private fun sendToast(msg: String) {
        viewModelScope.launch {
            _uiEvents.emit(msg)
        }
    }

    override fun onCleared() {
        super.onCleared()
        soundManager.release()
        autoSpinJob?.cancel()
    }
}
