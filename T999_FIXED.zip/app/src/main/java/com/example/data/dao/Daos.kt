package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.entity.AppConfigEntity
import com.example.data.entity.CoinPackageEntity
import com.example.data.entity.CoinTransactionEntity
import com.example.data.entity.GameHistoryEntity
import com.example.data.entity.NotificationEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.data.entity.PromoCodeEntity
import com.example.data.entity.UserEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun getUserFlow(userId: Long): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUserById(userId: Long): UserEntity?

    @Query("SELECT * FROM users WHERE phoneNumber = :phoneNumber LIMIT 1")
    suspend fun getUserByPhone(phoneNumber: String): UserEntity?

    @Query("SELECT * FROM users ORDER BY coinBalance DESC")
    fun getAllUsersFlow(): Flow<List<UserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserEntity): Long

    @Update
    suspend fun updateUser(user: UserEntity)

    @Query("UPDATE users SET coinBalance = coinBalance + :coins, totalPurchasedCoins = totalPurchasedCoins + :coins WHERE id = :userId")
    suspend fun creditPurchasedCoins(userId: Long, coins: Long)

    @Query("UPDATE users SET coinBalance = coinBalance + :coins, totalBonusCoins = totalBonusCoins + :coins WHERE id = :userId")
    suspend fun creditBonusCoins(userId: Long, coins: Long)

    @Query("UPDATE users SET coinBalance = coinBalance - :coins, totalUsedCoins = totalUsedCoins + :coins WHERE id = :userId")
    suspend fun debitCoins(userId: Long, coins: Long)
}

@Dao
interface PaymentRequestDao {
    @Query("SELECT * FROM payment_requests WHERE userId = :userId ORDER BY createdAt DESC")
    fun getPaymentsByUserFlow(userId: Long): Flow<List<PaymentRequestEntity>>

    @Query("SELECT * FROM payment_requests ORDER BY createdAt DESC")
    fun getAllPaymentsFlow(): Flow<List<PaymentRequestEntity>>

    @Query("SELECT * FROM payment_requests WHERE id = :id LIMIT 1")
    suspend fun getPaymentById(id: Long): PaymentRequestEntity?

    @Query("SELECT * FROM payment_requests WHERE transactionRefId = :refId LIMIT 1")
    suspend fun getPaymentByRefId(refId: String): PaymentRequestEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPayment(payment: PaymentRequestEntity): Long

    @Update
    suspend fun updatePayment(payment: PaymentRequestEntity)
}

@Dao
interface CoinTransactionDao {
    @Query("SELECT * FROM coin_transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun getTransactionsByUserFlow(userId: Long): Flow<List<CoinTransactionEntity>>

    @Query("SELECT * FROM coin_transactions ORDER BY timestamp DESC LIMIT 100")
    fun getAllTransactionsFlow(): Flow<List<CoinTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: CoinTransactionEntity): Long
}

@Dao
interface GameHistoryDao {
    @Query("SELECT * FROM game_history WHERE userId = :userId ORDER BY timestamp DESC LIMIT 50")
    fun getHistoryByUserFlow(userId: Long): Flow<List<GameHistoryEntity>>

    @Query("SELECT * FROM game_history ORDER BY timestamp DESC LIMIT 100")
    fun getAllGameHistoryFlow(): Flow<List<GameHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHistory(history: GameHistoryEntity): Long
}

@Dao
interface CoinPackageDao {
    @Query("SELECT * FROM coin_packages WHERE isActive = 1 ORDER BY coins ASC")
    fun getActivePackagesFlow(): Flow<List<CoinPackageEntity>>

    @Query("SELECT * FROM coin_packages ORDER BY coins ASC")
    fun getAllPackagesFlow(): Flow<List<CoinPackageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackage(pkg: CoinPackageEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPackages(pkgs: List<CoinPackageEntity>)

    @Update
    suspend fun updatePackage(pkg: CoinPackageEntity)

    @Query("DELETE FROM coin_packages WHERE id = :id")
    suspend fun deletePackage(id: Long)
}

@Dao
interface PromoCodeDao {
    @Query("SELECT * FROM promo_codes WHERE code = :code LIMIT 1")
    suspend fun getPromoCode(code: String): PromoCodeEntity?

    @Query("SELECT * FROM promo_codes ORDER BY rewardCoins DESC")
    fun getAllPromoCodesFlow(): Flow<List<PromoCodeEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPromoCode(promo: PromoCodeEntity)
}

@Dao
interface AppConfigDao {
    @Query("SELECT * FROM app_configs WHERE `key` = :key LIMIT 1")
    suspend fun getConfig(key: String): AppConfigEntity?

    @Query("SELECT * FROM app_configs")
    fun getAllConfigsFlow(): Flow<List<AppConfigEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setConfig(config: AppConfigEntity)
}

@Dao
interface NotificationDao {
    @Query("SELECT * FROM notifications WHERE userId = :userId OR userId = 0 ORDER BY timestamp DESC")
    fun getNotificationsFlow(userId: Long): Flow<List<NotificationEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: NotificationEntity): Long

    @Query("UPDATE notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllRead(userId: Long)
}
