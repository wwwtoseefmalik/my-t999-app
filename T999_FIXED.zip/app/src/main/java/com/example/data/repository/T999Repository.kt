package com.example.data.repository

import com.example.data.database.T999Database
import com.example.data.entity.AppConfigEntity
import com.example.data.entity.CoinPackageEntity
import com.example.data.entity.CoinTransactionEntity
import com.example.data.entity.GameHistoryEntity
import com.example.data.entity.NotificationEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.data.entity.UserEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

class T999Repository(private val database: T999Database) {

    private val userDao = database.userDao()
    private val paymentDao = database.paymentRequestDao()
    private val txDao = database.coinTransactionDao()
    private val gameDao = database.gameHistoryDao()
    private val packageDao = database.coinPackageDao()
    private val promoDao = database.promoCodeDao()
    private val configDao = database.appConfigDao()
    private val notifDao = database.notificationDao()

    // Active user flow
    fun getUserFlow(userId: Long): Flow<UserEntity?> = userDao.getUserFlow(userId).flowOn(Dispatchers.IO)
    fun getAllUsersFlow(): Flow<List<UserEntity>> = userDao.getAllUsersFlow().flowOn(Dispatchers.IO)

    // Payments
    fun getPaymentsByUserFlow(userId: Long): Flow<List<PaymentRequestEntity>> =
        paymentDao.getPaymentsByUserFlow(userId).flowOn(Dispatchers.IO)

    fun getAllPaymentsFlow(): Flow<List<PaymentRequestEntity>> =
        paymentDao.getAllPaymentsFlow().flowOn(Dispatchers.IO)

    // Transactions
    fun getTransactionsByUserFlow(userId: Long): Flow<List<CoinTransactionEntity>> =
        txDao.getTransactionsByUserFlow(userId).flowOn(Dispatchers.IO)

    fun getAllTransactionsFlow(): Flow<List<CoinTransactionEntity>> =
        txDao.getAllTransactionsFlow().flowOn(Dispatchers.IO)

    // Game History
    fun getGameHistoryByUserFlow(userId: Long): Flow<List<GameHistoryEntity>> =
        gameDao.getHistoryByUserFlow(userId).flowOn(Dispatchers.IO)

    // Packages
    fun getActivePackagesFlow(): Flow<List<CoinPackageEntity>> =
        packageDao.getActivePackagesFlow().flowOn(Dispatchers.IO)

    fun getAllPackagesFlow(): Flow<List<CoinPackageEntity>> =
        packageDao.getAllPackagesFlow().flowOn(Dispatchers.IO)

    // Configs
    fun getAllConfigsFlow(): Flow<List<AppConfigEntity>> =
        configDao.getAllConfigsFlow().flowOn(Dispatchers.IO)

    // Notifications
    fun getNotificationsFlow(userId: Long): Flow<List<NotificationEntity>> =
        notifDao.getNotificationsFlow(userId).flowOn(Dispatchers.IO)

    // ---------------- AUTHENTICATION ----------------
    suspend fun loginOrRegister(phoneNumber: String, countryCode: String): Result<UserEntity> = withContext(Dispatchers.IO) {
        try {
            val cleanPhone = phoneNumber.trim().replace(" ", "").replace("-", "")
            if (cleanPhone.length < 7) {
                return@withContext Result.failure(Exception("Please enter a valid phone number"))
            }

            var user = userDao.getUserByPhone(cleanPhone)
            if (user == null) {
                // Determine if admin
                val isAdmin = cleanPhone == "9999999999" || cleanPhone == "990666708"
                val newUser = UserEntity(
                    phoneNumber = cleanPhone,
                    countryCode = countryCode,
                    userName = if (isAdmin) "Admin Master" else "Player_${cleanPhone.takeLast(4)}",
                    avatarIndex = Random.nextInt(1, 5),
                    coinBalance = if (isAdmin) 999999L else 500L,
                    totalPurchasedCoins = 0L,
                    totalUsedCoins = 0L,
                    totalBonusCoins = if (isAdmin) 999999L else 500L,
                    dailyStreak = 1,
                    lastDailyBonusClaimDate = "",
                    luckySpinsRemaining = 2,
                    inviteCode = "T999_${Random.nextInt(1000, 9999)}",
                    isAdmin = isAdmin
                )
                val id = userDao.insertUser(newUser)
                user = newUser.copy(id = id)

                // Welcome transaction
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = id,
                        amount = newUser.coinBalance,
                        type = "DAILY_BONUS",
                        description = "Welcome Signup Gift +${newUser.coinBalance} T999 Coins"
                    )
                )
            }
            Result.success(user)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun getUserById(userId: Long): UserEntity? = withContext(Dispatchers.IO) {
        userDao.getUserById(userId)
    }

    // ---------------- PAYMENTS / RECHARGE ----------------
    suspend fun submitPaymentRequest(
        userId: Long,
        packageId: Long,
        coinAmount: Long,
        priceRs: Double,
        paymentMethod: String,
        tillId: String,
        transactionRefId: String
    ): Result<PaymentRequestEntity> = withContext(Dispatchers.IO) {
        try {
            val cleanRef = transactionRefId.trim()
            if (cleanRef.isBlank()) {
                return@withContext Result.failure(Exception("Transaction Reference ID cannot be empty"))
            }
            if (coinAmount < 100L) {
                return@withContext Result.failure(Exception("Minimum recharge is 100 T999 Coins (Rs.100)"))
            }

            // Check duplicate reference ID
            val existing = paymentDao.getPaymentByRefId(cleanRef)
            if (existing != null) {
                return@withContext Result.failure(Exception("This Transaction Reference ID has already been submitted"))
            }

            val user = userDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))

            val request = PaymentRequestEntity(
                userId = userId,
                userName = user.userName,
                userPhone = "${user.countryCode} ${user.phoneNumber}",
                packageId = packageId,
                coins = coinAmount,
                priceRs = priceRs,
                paymentMethod = paymentMethod,
                tillId = tillId,
                transactionRefId = cleanRef,
                status = "Pending",
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            val newId = paymentDao.insertPayment(request)

            // Notify user
            notifDao.insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Recharge Request Submitted",
                    message = "Your request for $coinAmount T999 Coins (Ref: $cleanRef) is Pending verification.",
                    type = "PAYMENT"
                )
            )

            Result.success(request.copy(id = newId))
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updatePaymentStatus(
        paymentId: Long,
        newStatus: String,
        adminNotes: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val payment = paymentDao.getPaymentById(paymentId)
                ?: return@withContext Result.failure(Exception("Payment record not found"))

            if (payment.status == "Successful") {
                return@withContext Result.failure(Exception("Payment is already approved and credited"))
            }

            val updatedPayment = payment.copy(
                status = newStatus,
                adminNotes = adminNotes,
                updatedAt = System.currentTimeMillis()
            )
            paymentDao.updatePayment(updatedPayment)

            // If Successful, automatically credit coins!
            if (newStatus == "Successful") {
                userDao.creditPurchasedCoins(payment.userId, payment.coins)

                // Log transaction
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = payment.userId,
                        amount = payment.coins,
                        type = "RECHARGE",
                        description = "Recharge Approved: +${payment.coins} T999 Coins (Rs. ${payment.priceRs.toInt()})",
                        referenceId = payment.transactionRefId
                    )
                )

                // Notify user
                notifDao.insertNotification(
                    NotificationEntity(
                        userId = payment.userId,
                        title = "Payment Approved!",
                        message = "Your payment of Rs.${payment.priceRs.toInt()} has been verified! +${payment.coins} T999 Coins credited to your wallet.",
                        type = "PAYMENT"
                    )
                )
            } else if (newStatus == "Rejected" || newStatus == "Failed") {
                notifDao.insertNotification(
                    NotificationEntity(
                        userId = payment.userId,
                        title = "Payment $newStatus",
                        message = "Your recharge of ${payment.coins} Coins was marked as $newStatus. Reason: ${adminNotes ?: "Verification issue"}",
                        type = "PAYMENT"
                    )
                )
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- SLOT GAME ENGINE ----------------
    data class SpinResult(
        val reel1: SlotSymbol,
        val reel2: SlotSymbol,
        val reel3: SlotSymbol,
        val winMultiplier: Double,
        val winCoins: Long,
        val isJackpot: Boolean,
        val winLineDescription: String
    )

    enum class SlotSymbol(val title: String, val icon: String, val multiplier3x: Double, val colorHex: Long) {
        T999_WILD("T999 Wild", "⚡", 25.0, 0xFF00FF66),
        CROWN("Royal Crown", "👑", 15.0, 0xFFFFD700),
        NEON_SEVEN("Lucky 777", "7️⃣", 10.0, 0xFFFF3366),
        DIAMOND("Cyber Gem", "💎", 6.0, 0xFF00F0FF),
        COIN("T999 Coin", "💰", 4.0, 0xFFFFB800),
        STAR("Neon Star", "⭐", 3.0, 0xFFB026FF),
        BELL("Cyber Bell", "🔔", 2.0, 0xFF39FF14),
        CHERRY("Neon Cherry", "🍒", 1.5, 0xFFFF1493)
    }

    suspend fun playSlotSpin(userId: Long, betAmount: Long): Result<SpinResult> = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
            if (user.coinBalance < betAmount) {
                return@withContext Result.failure(Exception("Insufficient T999 Coins! Please recharge."))
            }

            // Deduct bet
            userDao.debitCoins(userId, betAmount)
            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = userId,
                    amount = -betAmount,
                    type = "GAME_BET",
                    description = "Slot Bet: -$betAmount T999 Coins"
                )
            )

            // Spin algorithm with fair and engaging social slot RTP
            val symbols = SlotSymbol.values()
            // Weighted random pool for fun gaming feel
            val weightedPool = listOf(
                SlotSymbol.CHERRY, SlotSymbol.CHERRY, SlotSymbol.CHERRY, SlotSymbol.CHERRY,
                SlotSymbol.BELL, SlotSymbol.BELL, SlotSymbol.BELL,
                SlotSymbol.STAR, SlotSymbol.STAR, SlotSymbol.STAR,
                SlotSymbol.COIN, SlotSymbol.COIN,
                SlotSymbol.DIAMOND, SlotSymbol.DIAMOND,
                SlotSymbol.NEON_SEVEN,
                SlotSymbol.CROWN,
                SlotSymbol.T999_WILD
            )

            val r1 = weightedPool.random()
            val r2 = weightedPool.random()
            val r3 = weightedPool.random()

            var multiplier = 0.0
            var isJackpot = false
            var winDesc = "No Win"

            // 3 matching
            if (r1 == r2 && r2 == r3) {
                multiplier = r1.multiplier3x
                if (r1 == SlotSymbol.T999_WILD) {
                    multiplier = 50.0 // Super Mega Jackpot
                    isJackpot = true
                    winDesc = "⚡ MEGA T999 JACKPOT (50x)!"
                } else if (r1 == SlotSymbol.CROWN || r1 == SlotSymbol.NEON_SEVEN) {
                    isJackpot = true
                    winDesc = "👑 BIG JACKPOT WIN (${multiplier.toInt()}x)!"
                } else {
                    winDesc = "🎉 TRIPLE MATCH (${multiplier.toInt()}x)!"
                }
            } else if (r1 == SlotSymbol.T999_WILD && r2 == SlotSymbol.T999_WILD) {
                multiplier = 10.0
                winDesc = "⚡ Double Wild (${multiplier.toInt()}x)!"
            } else if (r1 == r2 || r2 == r3 || r1 == r3) {
                // 2 matching
                val matchingSymbol = if (r1 == r2) r1 else if (r2 == r3) r2 else r1
                multiplier = (matchingSymbol.multiplier3x * 0.4).coerceAtLeast(1.2)
                winDesc = "✨ Double Match (${String.format(Locale.US, "%.1f", multiplier)}x)!"
            } else if (r1 == SlotSymbol.T999_WILD || r2 == SlotSymbol.T999_WILD || r3 == SlotSymbol.T999_WILD) {
                // Single Wild substitute
                multiplier = 1.5
                winDesc = "⚡ Wild Booster (1.5x)!"
            }

            val winCoins = (betAmount * multiplier).toLong()

            if (winCoins > 0) {
                userDao.creditBonusCoins(userId, winCoins)
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = userId,
                        amount = winCoins,
                        type = "GAME_WIN",
                        description = "Slot Win: +$winCoins T999 Coins ($winDesc)"
                    )
                )
            }

            // Log game history
            gameDao.insertHistory(
                GameHistoryEntity(
                    userId = userId,
                    gameName = "T999 Neon Wilds",
                    betAmount = betAmount,
                    winAmount = winCoins,
                    payoutMultiplier = multiplier,
                    reelsResult = "${r1.name},${r2.name},${r3.name}",
                    timestamp = System.currentTimeMillis()
                )
            )

            val result = SpinResult(
                reel1 = r1,
                reel2 = r2,
                reel3 = r3,
                winMultiplier = multiplier,
                winCoins = winCoins,
                isJackpot = isJackpot,
                winLineDescription = winDesc
            )

            Result.success(result)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- DAILY LOGIN BONUS ----------------
    suspend fun claimDailyBonus(userId: Long): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
            val todayStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())

            if (user.lastDailyBonusClaimDate == todayStr) {
                return@withContext Result.failure(Exception("Daily bonus already claimed for today! Come back tomorrow."))
            }

            val currentStreak = if (user.dailyStreak >= 7) 1 else user.dailyStreak + 1
            val bonusRewards = listOf(50L, 100L, 150L, 200L, 300L, 500L, 1000L)
            val rewardCoins = bonusRewards[(currentStreak - 1).coerceIn(0, 6)]

            val updatedUser = user.copy(
                coinBalance = user.coinBalance + rewardCoins,
                totalBonusCoins = user.totalBonusCoins + rewardCoins,
                dailyStreak = currentStreak,
                lastDailyBonusClaimDate = todayStr,
                luckySpinsRemaining = user.luckySpinsRemaining + 1
            )
            userDao.updateUser(updatedUser)

            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = userId,
                    amount = rewardCoins,
                    type = "DAILY_BONUS",
                    description = "Day $currentStreak Daily Bonus: +$rewardCoins T999 Coins"
                )
            )

            notifDao.insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Daily Bonus Claimed!",
                    message = "You received $rewardCoins T999 Coins for your Day $currentStreak streak + 1 Free Lucky Spin!",
                    type = "BONUS"
                )
            )

            Result.success(rewardCoins)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- LUCKY WHEEL SPIN ----------------
    suspend fun playLuckySpin(userId: Long): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val user = userDao.getUserById(userId) ?: return@withContext Result.failure(Exception("User not found"))
            if (user.luckySpinsRemaining <= 0 && user.coinBalance < 50L) {
                return@withContext Result.failure(Exception("No free spins! Need 50 T999 Coins to spin the Lucky Wheel."))
            }

            var usedFreeSpin = false
            if (user.luckySpinsRemaining > 0) {
                usedFreeSpin = true
                userDao.updateUser(user.copy(luckySpinsRemaining = user.luckySpinsRemaining - 1))
            } else {
                userDao.debitCoins(userId, 50L)
                txDao.insertTransaction(
                    CoinTransactionEntity(
                        userId = userId,
                        amount = -50L,
                        type = "LUCKY_SPIN",
                        description = "Lucky Wheel Spin Fee: -50 T999 Coins"
                    )
                )
            }

            val prizes = listOf(50L, 100L, 150L, 200L, 300L, 500L, 1000L, 2500L)
            val wonPrize = prizes.random()

            userDao.creditBonusCoins(userId, wonPrize)
            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = userId,
                    amount = wonPrize,
                    type = "LUCKY_SPIN",
                    description = "Lucky Wheel Prize: +$wonPrize T999 Coins"
                )
            )

            Result.success(wonPrize)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- PROMO CODES ----------------
    suspend fun redeemPromoCode(userId: Long, code: String): Result<Long> = withContext(Dispatchers.IO) {
        try {
            val cleanCode = code.trim().uppercase()
            val promo = promoDao.getPromoCode(cleanCode)
                ?: return@withContext Result.failure(Exception("Invalid or expired promo code"))

            if (!promo.isActive) {
                return@withContext Result.failure(Exception("This promo code has expired"))
            }

            userDao.creditBonusCoins(userId, promo.rewardCoins)
            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = userId,
                    amount = promo.rewardCoins,
                    type = "PROMO_CODE",
                    description = "Promo Code Redeemed [$cleanCode]: +${promo.rewardCoins} T999 Coins"
                )
            )

            notifDao.insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Promo Code Redeemed!",
                    message = "Successfully redeemed $cleanCode for +${promo.rewardCoins} T999 Coins!",
                    type = "BONUS"
                )
            )

            Result.success(promo.rewardCoins)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    // ---------------- ADMIN ACTIONS ----------------
    suspend fun addCoinPackage(coins: Long, priceRs: Double, tag: String?, isPopular: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            if (coins < 100L) {
                return@withContext Result.failure(Exception("Rule Violation: Minimum package size must be at least 100 T999 Coins"))
            }
            packageDao.insertPackage(
                CoinPackageEntity(
                    coins = coins,
                    priceRs = priceRs,
                    tag = tag,
                    isPopular = isPopular,
                    isActive = true
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePackage(id: Long) = withContext(Dispatchers.IO) {
        packageDao.deletePackage(id)
    }

    suspend fun updateAppConfig(key: String, value: String) = withContext(Dispatchers.IO) {
        configDao.setConfig(AppConfigEntity(key = key, value = value))
    }

    suspend fun adminCreditUserCoins(userId: Long, coins: Long, reason: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            userDao.creditBonusCoins(userId, coins)
            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = userId,
                    amount = coins,
                    type = "ADMIN_CREDIT",
                    description = "Admin Grant: +$coins T999 Coins ($reason)"
                )
            )
            notifDao.insertNotification(
                NotificationEntity(
                    userId = userId,
                    title = "Special Admin Gift",
                    message = "You received +$coins T999 Coins from Admin: $reason",
                    type = "BONUS"
                )
            )
            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
