package com.example.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.AppConfigDao
import com.example.data.dao.CoinPackageDao
import com.example.data.dao.CoinTransactionDao
import com.example.data.dao.GameHistoryDao
import com.example.data.dao.NotificationDao
import com.example.data.dao.PaymentRequestDao
import com.example.data.dao.PromoCodeDao
import com.example.data.dao.UserDao
import com.example.data.entity.AppConfigEntity
import com.example.data.entity.CoinPackageEntity
import com.example.data.entity.CoinTransactionEntity
import com.example.data.entity.GameHistoryEntity
import com.example.data.entity.NotificationEntity
import com.example.data.entity.PaymentRequestEntity
import com.example.data.entity.PromoCodeEntity
import com.example.data.entity.UserEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        UserEntity::class,
        PaymentRequestEntity::class,
        CoinTransactionEntity::class,
        GameHistoryEntity::class,
        CoinPackageEntity::class,
        PromoCodeEntity::class,
        AppConfigEntity::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class T999Database : RoomDatabase() {

    abstract fun userDao(): UserDao
    abstract fun paymentRequestDao(): PaymentRequestDao
    abstract fun coinTransactionDao(): CoinTransactionDao
    abstract fun gameHistoryDao(): GameHistoryDao
    abstract fun coinPackageDao(): CoinPackageDao
    abstract fun promoCodeDao(): PromoCodeDao
    abstract fun appConfigDao(): AppConfigDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile
        private var INSTANCE: T999Database? = null

        fun getDatabase(context: Context, scope: CoroutineScope): T999Database {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    T999Database::class.java,
                    "t999_gaming.db"
                ).addCallback(DatabaseCallback(scope)).build()
                INSTANCE = instance
                instance
            }
        }
    }

    private class DatabaseCallback(
        private val scope: CoroutineScope
    ) : Callback() {
        override fun onCreate(db: SupportSQLiteDatabase) {
            super.onCreate(db)
            INSTANCE?.let { database ->
                scope.launch(Dispatchers.IO) {
                    populateInitialData(database)
                }
            }
        }

        private suspend fun populateInitialData(database: T999Database) {
            // Seed packages exactly as required
            val packageDao = database.coinPackageDao()
            val initialPackages = listOf(
                CoinPackageEntity(coins = 100L, priceRs = 100.0, tag = "Starter Pack", isPopular = false, isActive = true),
                CoinPackageEntity(coins = 250L, priceRs = 250.0, tag = "Popular Choice", isPopular = true, isActive = true),
                CoinPackageEntity(coins = 500L, priceRs = 500.0, tag = "Mega Fortune", isPopular = false, isActive = true)
            )
            packageDao.insertPackages(initialPackages)

            // Seed App Configs
            val configDao = database.appConfigDao()
            configDao.setConfig(AppConfigEntity(key = "till_id", value = "990666708"))
            configDao.setConfig(AppConfigEntity(key = "payment_method", value = "TILL Payment"))
            configDao.setConfig(AppConfigEntity(key = "min_recharge", value = "100"))
            configDao.setConfig(AppConfigEntity(key = "announcement", value = "Welcome to T999 Social Slots! Virtual coins only. Enjoy daily spins & bonuses!"))

            // Seed Default User (Demo account)
            val userDao = database.userDao()
            val demoUser = UserEntity(
                id = 1L,
                phoneNumber = "9876543210",
                countryCode = "+91",
                userName = "NeonPlayer999",
                avatarIndex = 1,
                coinBalance = 500L,
                totalPurchasedCoins = 0L,
                totalUsedCoins = 0L,
                totalBonusCoins = 500L,
                dailyStreak = 1,
                lastDailyBonusClaimDate = "",
                luckySpinsRemaining = 2,
                inviteCode = "T999VIP",
                isAdmin = false
            )
            userDao.insertUser(demoUser)

            // Seed Admin User
            val adminUser = UserEntity(
                id = 999L,
                phoneNumber = "9999999999",
                countryCode = "+91",
                userName = "T999 Admin Master",
                avatarIndex = 3,
                coinBalance = 999999L,
                totalPurchasedCoins = 10000L,
                totalUsedCoins = 0L,
                totalBonusCoins = 999999L,
                dailyStreak = 7,
                lastDailyBonusClaimDate = "",
                luckySpinsRemaining = 99,
                inviteCode = "ADMIN999",
                isAdmin = true
            )
            userDao.insertUser(adminUser)

            // Seed initial promo codes
            val promoDao = database.promoCodeDao()
            promoDao.insertPromoCode(PromoCodeEntity(code = "T999WELCOME", rewardCoins = 100L, description = "Welcome Gift: +100 T999 Coins", isActive = true))
            promoDao.insertPromoCode(PromoCodeEntity(code = "NEON999", rewardCoins = 150L, description = "Neon Special: +150 T999 Coins", isActive = true))
            promoDao.insertPromoCode(PromoCodeEntity(code = "LUCKY777", rewardCoins = 200L, description = "Lucky 777: +200 T999 Coins", isActive = true))

            // Seed initial Welcome Transaction
            val txDao = database.coinTransactionDao()
            txDao.insertTransaction(
                CoinTransactionEntity(
                    userId = 1L,
                    amount = 500L,
                    type = "DAILY_BONUS",
                    description = "Welcome Signup Bonus +500 T999 Coins"
                )
            )

            // Seed Notification
            val notifDao = database.notificationDao()
            notifDao.insertNotification(
                NotificationEntity(
                    userId = 1L,
                    title = "Welcome to T999 Gaming!",
                    message = "You received 500 Starter T999 Coins. Spin the reels & claim your daily bonus!",
                    type = "BONUS"
                )
            )
        }
    }
}
