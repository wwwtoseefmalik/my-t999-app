package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val phoneNumber: String,
    val countryCode: String = "+91",
    val userName: String,
    val avatarIndex: Int = 1,
    val coinBalance: Long = 500L, // Starter social welcome coins
    val totalPurchasedCoins: Long = 0L,
    val totalUsedCoins: Long = 0L,
    val totalBonusCoins: Long = 500L,
    val dailyStreak: Int = 1,
    val lastDailyBonusClaimDate: String = "",
    val luckySpinsRemaining: Int = 1,
    val inviteCode: String = "T999VIP",
    val isAdmin: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "payment_requests")
data class PaymentRequestEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val userName: String,
    val userPhone: String,
    val packageId: Long,
    val coins: Long,
    val priceRs: Double,
    val paymentMethod: String = "TILL Payment",
    val tillId: String = "990666708",
    val transactionRefId: String,
    val status: String = "Pending", // "Pending", "Payment Received", "Successful", "Failed", "Rejected"
    val adminNotes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "coin_transactions")
data class CoinTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val amount: Long, // positive for credit, negative for debit
    val type: String, // "RECHARGE", "GAME_BET", "GAME_WIN", "DAILY_BONUS", "LUCKY_SPIN", "PROMO_CODE", "ADMIN_CREDIT", "REFERRAL_BONUS"
    val description: String,
    val referenceId: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "game_history")
data class GameHistoryEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val gameName: String,
    val betAmount: Long,
    val winAmount: Long,
    val payoutMultiplier: Double,
    val reelsResult: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "coin_packages")
data class CoinPackageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val coins: Long,
    val priceRs: Double,
    val tag: String? = null,
    val isPopular: Boolean = false,
    val isActive: Boolean = true
)

@Entity(tableName = "promo_codes")
data class PromoCodeEntity(
    @PrimaryKey
    val code: String,
    val rewardCoins: Long,
    val description: String,
    val isActive: Boolean = true
)

@Entity(tableName = "app_configs")
data class AppConfigEntity(
    @PrimaryKey
    val key: String,
    val value: String
)

@Entity(tableName = "notifications")
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val userId: Long,
    val title: String,
    val message: String,
    val type: String = "SYSTEM",
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)
