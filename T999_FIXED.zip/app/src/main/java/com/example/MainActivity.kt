package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.Stars
import androidx.compose.material.icons.filled.Wallet
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.ui.screens.admin.AdminPanelScreen
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.features.FeaturesScreen
import com.example.ui.screens.home.HomeScreen
import com.example.ui.screens.recharge.BuyCoinsScreen
import com.example.ui.screens.slot.SlotGameScreen
import com.example.ui.screens.wallet.WalletScreen
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkCardBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeonGreen
import com.example.ui.theme.NeonGreenBright
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextOnNeon
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.viewmodel.T999ViewModel
import kotlinx.coroutines.flow.collectLatest

sealed class Screen(val route: String, val title: String, val icon: ImageVector) {
    object Home : Screen("home", "Lobby", Icons.Default.Home)
    object Slot : Screen("slot", "Slots", Icons.Default.Casino)
    object BuyCoins : Screen("recharge", "Buy Coins", Icons.Default.ShoppingBag)
    object Wallet : Screen("wallet", "Wallet", Icons.Default.Wallet)
    object Features : Screen("features", "Rewards", Icons.Default.CardGiftcard)
    object Admin : Screen("admin", "Admin", Icons.Default.AdminPanelSettings)
    object Auth : Screen("auth", "Auth", Icons.Default.Home)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                T999MainApp()
            }
        }
    }
}

@Composable
fun T999MainApp(viewModel: T999ViewModel = viewModel()) {
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }
    val currentUser by viewModel.currentUser.collectAsState()

    // Handle toast messages
    LaunchedEffect(Unit) {
        viewModel.uiEvents.collectLatest { msg ->
            snackbarHostState.showSnackbar(msg)
        }
    }

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val bottomNavItems = if (currentUser?.isAdmin == true) {
        listOf(Screen.Home, Screen.Slot, Screen.BuyCoins, Screen.Wallet, Screen.Features, Screen.Admin)
    } else {
        listOf(Screen.Home, Screen.Slot, Screen.BuyCoins, Screen.Wallet, Screen.Features)
    }

    val showBottomBar = currentRoute != Screen.Auth.route

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        bottomBar = {
            if (showBottomBar) {
                NavigationBar(
                    containerColor = DarkSurface,
                    tonalElevation = 8.dp,
                    modifier = Modifier.height(72.dp)
                ) {
                    bottomNavItems.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        val selectedColor = if (screen == Screen.Admin) GoldAccent else NeonGreenBright

                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                viewModel.soundManager.playButtonClick()
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(
                                    imageVector = screen.icon,
                                    contentDescription = screen.title,
                                    modifier = Modifier.size(22.dp)
                                )
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TextOnNeon,
                                selectedTextColor = selectedColor,
                                unselectedIconColor = TextMuted,
                                unselectedTextColor = TextMuted,
                                indicatorColor = if (screen == Screen.Admin) GoldAccent else NeonGreen
                            ),
                            modifier = Modifier.testTag("nav_tab_${screen.route}")
                        )
                    }
                }
            }
        },
        containerColor = DarkBackground,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            // AUTH SCREEN
            composable(Screen.Auth.route) {
                AuthScreen(
                    viewModel = viewModel,
                    onAuthSuccess = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Auth.route) { inclusive = true }
                        }
                    }
                )
            }

            // HOME LOBBY SCREEN
            composable(Screen.Home.route) {
                HomeScreen(
                    viewModel = viewModel,
                    onNavigateToSlot = { navController.navigate(Screen.Slot.route) },
                    onNavigateToRecharge = { navController.navigate(Screen.BuyCoins.route) },
                    onNavigateToWallet = { navController.navigate(Screen.Wallet.route) },
                    onNavigateToPaymentHistory = { navController.navigate(Screen.Wallet.route) },
                    onNavigateToLuckySpin = { navController.navigate(Screen.Features.route) },
                    onNavigateToDailyBonus = { navController.navigate(Screen.Features.route) },
                    onNavigateToLeaderboard = { navController.navigate(Screen.Features.route) },
                    onNavigateToReferral = { navController.navigate(Screen.Features.route) },
                    onNavigateToAdmin = { navController.navigate(Screen.Admin.route) },
                    onNavigateToProfile = { navController.navigate(Screen.Auth.route) }
                )
            }

            // SLOT GAME SCREEN
            composable(Screen.Slot.route) {
                SlotGameScreen(
                    viewModel = viewModel,
                    onNavigateToRecharge = { navController.navigate(Screen.BuyCoins.route) }
                )
            }

            // BUY COINS SCREEN
            composable(Screen.BuyCoins.route) {
                BuyCoinsScreen(
                    viewModel = viewModel,
                    onNavigateToHistory = { navController.navigate(Screen.Wallet.route) },
                    onNavigateToWallet = { navController.navigate(Screen.Wallet.route) }
                )
            }

            // WALLET SCREEN
            composable(Screen.Wallet.route) {
                WalletScreen(
                    viewModel = viewModel,
                    onNavigateToRecharge = { navController.navigate(Screen.BuyCoins.route) }
                )
            }

            // FEATURES HUB SCREEN
            composable(Screen.Features.route) {
                FeaturesScreen(
                    viewModel = viewModel,
                    onNavigateToRecharge = { navController.navigate(Screen.BuyCoins.route) }
                )
            }

            // ADMIN PANEL SCREEN
            composable(Screen.Admin.route) {
                AdminPanelScreen(
                    viewModel = viewModel
                )
            }
        }
    }
}
