package com.example.audio

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SoundManager(private val context: Context) {

    private var toneGenerator: ToneGenerator? = null
    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    var isSoundEnabled: Boolean = true
    var isVibrationEnabled: Boolean = true

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 70)
        } catch (e: Exception) {
            toneGenerator = null
        }
    }

    fun playButtonClick() {
        if (isSoundEnabled) {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 30)
        }
        vibrate(20)
    }

    fun playSpinTick() {
        if (isSoundEnabled) {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 25)
        }
        vibrate(15)
    }

    fun playReelStop() {
        if (isSoundEnabled) {
            toneGenerator?.startTone(ToneGenerator.TONE_DTMF_D, 40)
        }
        vibrate(30)
    }

    fun playWinSound(scope: CoroutineScope) {
        if (isSoundEnabled) {
            scope.launch(Dispatchers.Default) {
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_9, 100)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_0, 100)
                delay(120)
                toneGenerator?.startTone(ToneGenerator.TONE_DTMF_D, 180)
            }
        }
        vibratePattern(longArrayOf(0, 50, 50, 100))
    }

    fun playJackpotSound(scope: CoroutineScope) {
        if (isSoundEnabled) {
            scope.launch(Dispatchers.Default) {
                val notes = listOf(
                    ToneGenerator.TONE_DTMF_1,
                    ToneGenerator.TONE_DTMF_4,
                    ToneGenerator.TONE_DTMF_7,
                    ToneGenerator.TONE_DTMF_9,
                    ToneGenerator.TONE_DTMF_D
                )
                for (n in notes) {
                    toneGenerator?.startTone(n, 120)
                    delay(130)
                }
                toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 300)
            }
        }
        vibratePattern(longArrayOf(0, 80, 50, 120, 50, 200))
    }

    fun playCoinClink() {
        if (isSoundEnabled) {
            toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP2, 50)
        }
        vibrate(25)
    }

    private fun vibrate(ms: Long) {
        if (!isVibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(ms)
            }
        } catch (e: Exception) {
            // Ignore if vibration unavailable
        }
    }

    private fun vibratePattern(pattern: LongArray) {
        if (!isVibrationEnabled) return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(pattern, -1)
            }
        } catch (e: Exception) {
            // Ignore
        }
    }

    fun release() {
        try {
            toneGenerator?.release()
            toneGenerator = null
        } catch (e: Exception) {
            // Ignore
        }
    }
}
