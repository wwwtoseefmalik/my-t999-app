package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.database.T999Database
import com.example.data.repository.T999Repository
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.test.TestScope
import kotlinx.coroutines.test.runTest
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@OptIn(ExperimentalCoroutinesApi::class)
@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `verify app name resource is T999`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("T999", appName)
    }

    @Test
    fun `verify user login and coin balance in repository`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val database = T999Database.getDatabase(context, this)
        val repository = T999Repository(database)

        val result = repository.loginOrRegister("9876543210", "+91")
        assertTrue(result.isSuccess)
        val user = result.getOrNull()
        assertNotNull(user)
        assertTrue((user?.coinBalance ?: 0) >= 100)
    }

    @Test
    fun `verify minimum recharge rule enforcement`() = runTest {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val database = T999Database.getDatabase(context, this)
        val repository = T999Repository(database)

        val userResult = repository.loginOrRegister("9876543210", "+91")
        val user = userResult.getOrThrow()

        // Attempting to submit recharge below 100 coins should fail
        val failedResult = repository.submitPaymentRequest(
            userId = user.id,
            packageId = 99L,
            coinAmount = 50L,
            priceRs = 50.0,
            paymentMethod = "TILL Payment",
            tillId = "990666708",
            transactionRefId = "TXN_TEST_123"
        )
        assertTrue(failedResult.isFailure)

        // Submitting recharge of 100 coins should succeed with status Pending
        val validResult = repository.submitPaymentRequest(
            userId = user.id,
            packageId = 1L,
            coinAmount = 100L,
            priceRs = 100.0,
            paymentMethod = "TILL Payment",
            tillId = "990666708",
            transactionRefId = "TXN_TEST_456"
        )
        assertTrue(validResult.isSuccess)
    }
}
